# Web-Fontmin

Web Fontmin 可以让你可以在线提取字体，基于 Fontmin 构建。

### Screenshot

![page-1](https://raw.githubusercontent.com/forsigner/blog/master/source/images/web-fontmin/page-1.png)
![page-2](https://raw.githubusercontent.com/forsigner/blog/master/source/images/web-fontmin/page-2.png)


### Dev

如果你想参与 Web Fontmin 的开发，可按照以下步骤配置开发环境。

First: fork it

And then:

```bash
$ git clone [repos]
$ npm install
$ bower install
$ gulp
```

### License

  [MIT](LICENSE)
