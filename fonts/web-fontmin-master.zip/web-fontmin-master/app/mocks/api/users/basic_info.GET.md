### response with 200

```js
//<response=200>
// 返回200

{"email":"1031098736@qq.com","name":"1031098736@qq.com","id":"5655dee5e0f55a7b7f00014d","auth_token":"gf6WxW7GF3usOnxmDMS3"}

```
