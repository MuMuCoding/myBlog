### response with 200

```js
//<response=200>
// 返回200
{
  "cursor":0,
  "count":10,
  "total":20,
  "data":[{
    "id":1,
    "msgName":"测试礼包码",
    "createTime":1459136210000,
    "beginTime":1459136210000,
    "endTime":1459136210000,
    "updateTime":1459136210000,
    "status":1,
    "count":100,
    "maxGiftForUser":20,
    "maxUserForGift":20,
    "gotPerson":5,
    "gotCount":5,
    "mutualCode": 1,
    "batchCode":1
  },{
    "id":2,
    "msgName":"测试礼包码",
    "createTime":1459136210000,
    "beginTime":1459136210000,
    "endTime":1459136210000,
    "updateTime":1459136210000,
    "status":1,
    "count":100,
    "maxGiftForUser":20,
    "maxUserForGift":20,
    "gotPerson":5,
    "gotCount":5,
    "mutualCode": 1,
    "batchCode":1
  },{
    "id":3,
    "msgName":"测试礼包码1",
    "createTime":1459136210000,
    "beginTime":1459136210000,
    "endTime":1459136210000,
    "updateTime":1459136210000,
    "status":-1,
    "count":100,
    "maxGiftForUser":20,
    "maxUserForGift":20,
    "gotPerson":5,
    "gotCount":5,
    "mutualCode": 1,
    "batchCode":1
  }]
}
```
