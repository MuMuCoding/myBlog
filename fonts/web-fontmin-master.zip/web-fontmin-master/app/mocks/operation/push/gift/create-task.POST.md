### response with 200

```js
//<response=200>
// 返回200
{
    "code": 0,
    "msg": "新建活动不能和已有活动重名"
}
```
