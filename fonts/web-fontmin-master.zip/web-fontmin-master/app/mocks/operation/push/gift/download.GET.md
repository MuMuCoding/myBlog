### response with 200

```js
//<response=200>
// 返回200
{
    "code": 0,
    "msg": "1",
    "content": "abc,def,ghi"
}
```
