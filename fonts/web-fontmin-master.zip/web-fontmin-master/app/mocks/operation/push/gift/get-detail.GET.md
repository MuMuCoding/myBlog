### response with 200

```js
//<response=200>
// 返回200
[{"activityId":12,"channelId":"2","channelName":"未知，待定","createTime":1459396365655,"giftCode":"1234abcd","id":2,"roleId":"fdsa","roleName":"小苹果","serverId":"2","serverName":"服2","uid":"待定","zoneId":"1","zoneName":"区1"}, {"activityId":12,"channelId":"2","channelName":"未知，待定","createTime":1459396365655,"giftCode":"1234abcd","id":3,"roleId":"fdsa","roleName":"小苹果","serverId":"2","serverName":"服2","uid":"待定","zoneId":"1","zoneName":"区1"}, {"activityId":11,"channelId":"2","channelName":"未知，待定","createTime":1459396365655,"giftCode":"1234abcd","id":4,"roleId":"fdsa","roleName":"小苹果","serverId":"2","serverName":"服2","uid":"待定","zoneId":"1","zoneName":"区1"}, {"activityId":123,"channelId":"2","channelName":"未知，待定","createTime":1459396365655,"giftCode":"1234abcd","id":5,"roleId":"abc","roleName":"小苹果","serverId":"2","serverName":"服2","uid":"待定","zoneId":"1","zoneName":"区1"}]

```
