### response with 200

```js
//<response=200>
// 返回200
{
  "id": 1,
  "appId": "2003",
  "platform": "ANDROID",

  "msgName": "测试礼包码",
  "servers": "[{\"zoneId\":\"1\",\"zoneName\":\"区1\",\"serverId\":\"1\",\"serverName\":\"服1\"},{\"zoneId\":\"1\",\"zoneName\":\"区1\",\"serverId\":\"2\",\"serverName\":\"服2\"}]",
  "channels": "1,2",
  "minLevel": "1",
  "maxLevel": "4",
  "missions": "1,3",
  "toAll": 0,

  "giftName": "礼包测试名称",
  "giftDescription": "一个礼包",
  "giftContent": "[\"1*2\",\"2*4\",\"3*8\"]",
  "maxGiftForUser": 20,
  "maxUserForGift": 20,
  "mutualCode": "abc",
  "count": 99,
  "beginTime": 1459249210000,
  "endTime": 1459259210000,

  "gameNotifyUrl": "www.baidu.com",
  "bgImg": "https://doc.xgsdk.com:12345/upload/activity/pushtask/100/bg-ori.png",
  "bgInput": "https://doc.xgsdk.com:12345/upload/activity/pushtask/100/input-bg.png",
  "bgSubmit": "https://doc.xgsdk.com:12345/upload/activity/pushtask/100/submit.png",
  "positionInputBox": "{x:52.8,y:25,w:40,h:25}"
}
```
