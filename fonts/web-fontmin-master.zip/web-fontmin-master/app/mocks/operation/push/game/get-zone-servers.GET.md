### response with 200

```js
//<response=200>
// 返回200
[{
  "zoneId": 1,
  "zoneName": "区1",
  "serverId": 1,
  "serverName": "服1"
},{
  "zoneId": 1,
  "zoneName": "区1",
  "serverId": 2,
  "serverName": "服2"
},{
  "zoneId": 1,
  "zoneName": "区1",
  "serverId": 3,
  "serverName": "服3"
},{
  "zoneId": 2,
  "zoneName": "区2",
  "serverId": 1,
  "serverName": "服1"
},{
  "zoneId": 2,
  "zoneName": "区2",
  "serverId": 2,
  "serverName": "服2"
}]
```
