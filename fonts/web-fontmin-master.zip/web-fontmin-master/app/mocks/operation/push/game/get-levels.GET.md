### response with 200

```js
//<response=200>
// 返回200
[{
  "id": 1,
  "name": "等级1"
},{
  "id": 2,
  "name": "等级2"
},{
  "id": 3,
  "name": "等级3"
},{
  "id": 4,
  "name": "等级4"
},{
  "id": 5,
  "name": "等级5"
}]
```
