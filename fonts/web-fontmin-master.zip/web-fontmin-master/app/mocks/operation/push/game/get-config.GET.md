### response with 200

```js
//<response=200>
// 返回200
{
  "id": 1,
  "appId": "*",
  "giftGiftsUrl": "http://120.92.3.10:10800/item",
  "giftServersUrl": "http://120.92.3.10:10800/area",
  "giftMissionsUrl": "http://120.92.3.10:10800/level",
  "giftUsersUrl": "http://doc.xgsdk.com:8040/push/gift/query-userinfo-mock",
  "giftDispatchUrl": "http://doc.xgsdk.com:8040/push/gift/dispatch-gift-mock",
  "bgImg": "https://doc.xgsdk.com:12345/upload/1459821863902_1.jpg",
  "bgInput": "https://doc.xgsdk.com:12345/upload/1459821858589_4.jpg",
  "bgSubmit": "https://doc.xgsdk.com:12345/upload/1459821862180_3.jpg",
  "positionInputBox": "{\"y\":66.95,\"x\":12.56,\"w\":75.5,\"h\":5.16}",
  "expiredAlert": "对不起，该礼包码已过期",
  "wrongServerAlert": "对不起，该礼包码无法在该服务器使用",
  "wrongMissionAlert": "对不起，您没有通过礼包码要求的关卡",
  "wrongMinLevelAlert": "对不起，您的等级低于领取礼包最小等级要求",
  "wrongMaxLevelAlert": "对不起，您的等级高于领取礼包最大等级要求",
  "wrongChannelAlert": "对不起，该礼包无法在该渠道使用",
  "dupAlert": "对不起，用户不能重复领取礼包",
  "wrongMaxUserForGiftAlert": "对不起，改礼包码领取次数已用完",
  "wrongMaxGiftForUserAlert": "对不起，您领取次数已超过限制",
  "wrongMutualAlert": "礼包码在同一互斥组",
  "useReceivePage": false,
  "successAlert": "成功领取礼包"
}
```
