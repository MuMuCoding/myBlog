### response with 200

```js
//<response=200>
// 返回200
[{
  "id": 1,
  "name": "渠道1"
},{
  "id": 2,
  "name": "渠道2"
},{
  "id": 3,
  "name": "渠道3"
},{
  "id": 4,
  "name": "渠道4"
},{
  "id": 5,
  "name": "渠道5"
}]
```
