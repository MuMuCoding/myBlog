# 创建游戏


### request

```js
//<request>
{
  type: 'create-game',
  requestSystem: 'sdkportal',
  ts: '20150723150028',
  accessToken: 'xxxx',
  appName: 'hello world'
  appDesc: '游戏描述',
  appType: 'xxx',
  icon: 'a blob',
  sign: 'xxxx'
}

```

### response with 200

```js
//<response=200>
// 200
```
