### response with 200

```js
//<response=200>
// 返回200
{
    "code": 0,
    "fileName": "haha",
    "fileNameWithTs": 'lala',
    "fileUrl": "https://doc.xgsdk.com:12345/upload/桌面.jpg"
}
```
