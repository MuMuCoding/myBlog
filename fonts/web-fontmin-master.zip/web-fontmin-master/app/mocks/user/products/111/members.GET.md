### request

```js
//<request>
{

}

```

### response with 200

```js
//<response=200>
{
  code: 0,
  msg: 'xxxx',
  data: [
    {
      merberId: '2',
      name: '高菲',
      email: '123w546567568@qq.com',
      role: 'admin'
    },
    {
      merberId: '23',
      name: '曼玲',
      email: '12sfdg8@qq.com',
      role: 'member'
    },
    {
      merberId: '12',
      name: '志毅',
      email: '17568@qq.com',
      role: 'admin'
    },
    {
      merberId: '52',
      name: '山山',
      email: '123w546567568@qq.com',
      role: 'admin'
    },
    {
      merberId: '45',
      name: '宋琳',
      email: '123w546567568@qq.com',
      role: 'admin'
    },
  ]

}

```
