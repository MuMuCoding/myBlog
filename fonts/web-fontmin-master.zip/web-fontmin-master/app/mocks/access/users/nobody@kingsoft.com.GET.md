### response with 200

```js
//<response=200>
{
  "response": {
    "status": 404
  }
}
```