### response with 200

```js
//<response=200>
[
  {
    "packageName": "com.xg.sdk"
  },
  {
    "packageName": "com.google.keep"
  },
  {
    "packageName": "com.tencent.weixin"
  }
]

```