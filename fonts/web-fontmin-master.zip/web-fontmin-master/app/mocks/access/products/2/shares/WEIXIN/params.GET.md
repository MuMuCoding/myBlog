### response with 200

```js
//<response=200>
// /products/:product:id/platforms/:platformId/packages/com.xg.sdk/params.GET.response.js

 [
  {
    "name": "appId",
    "alias": "Weixinnn AppID",
    "value": "aaaaaaaaaaaa",
    "defaultValue": "xxxxxxxxxx12"
  },
  {
    "name": "appSecret",
    "alias": "AppSecret",
    "value": "gggggggggggg",
    "defaultValue": "xxxxxxxxxx12"
  },
  {
    "name": "signature",
    "alias": "签名",
    "value": "xgssgererwfsf",
    "defaultValue": "xxxxxxxxxx12"
  },
  {
    "name": "packageName",
    "alias": "包名",
    "value": "com.xg.sdk",
    "defaultValue": "xxxxxxxxxx12"
  }
 ]

```
