### response with 200

```js
//<response=200>
[
    {
        "channelParamValues": [
            {
                "paramId": 129200400,
                "planChannelId": 36003,
                "value": "2421",
                "file": null,
                "createTime": 1458200852000,
                "updateTime": 1458200852000,
                "latestUpdateUser": 1199,
                "planId": 2675,
                "channelId": "aiyouxi",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 116200500,
                "planChannelId": 36011,
                "value": "1",
                "file": null,
                "createTime": 1458200852000,
                "updateTime": 1458200852000,
                "latestUpdateUser": 1199,
                "planId": 2675,
                "channelId": "coolpad",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 108200400,
                "planChannelId": 36032,
                "value": "1",
                "file": null,
                "createTime": 1458200852000,
                "updateTime": 1458200852000,
                "latestUpdateUser": 1199,
                "planId": 2675,
                "channelId": "lenovo",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 127200300,
                "planChannelId": 36050,
                "value": "321312",
                "file": null,
                "createTime": 1458200852000,
                "updateTime": 1458200852000,
                "latestUpdateUser": 1199,
                "planId": 2675,
                "channelId": "sogou",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 143200200,
                "planChannelId": 36054,
                "value": "1",
                "file": null,
                "createTime": 1458200852000,
                "updateTime": 1458200852000,
                "latestUpdateUser": 1199,
                "planId": 2675,
                "channelId": "unicom",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 129200400,
                "planChannelId": 35463,
                "value": "2421",
                "file": null,
                "createTime": 1458198020000,
                "updateTime": 1458198091000,
                "latestUpdateUser": 1199,
                "planId": 2664,
                "channelId": "aiyouxi",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 116200500,
                "planChannelId": 35471,
                "value": "1",
                "file": null,
                "createTime": 1458199180000,
                "updateTime": 1458199180000,
                "latestUpdateUser": 1199,
                "planId": 2664,
                "channelId": "coolpad",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 108200400,
                "planChannelId": 35492,
                "value": "1",
                "file": null,
                "createTime": 1458198939000,
                "updateTime": 1458198939000,
                "latestUpdateUser": 1199,
                "planId": 2664,
                "channelId": "lenovo",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 127200200,
                "planChannelId": 35510,
                "value": "321312",
                "file": null,
                "createTime": 1458200842000,
                "updateTime": 1458200842000,
                "latestUpdateUser": 1199,
                "planId": 2664,
                "channelId": "sogou",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 143200200,
                "planChannelId": 35514,
                "value": "1",
                "file": null,
                "createTime": 1458198275000,
                "updateTime": 1458198275000,
                "latestUpdateUser": 1199,
                "planId": 2664,
                "channelId": "unicom",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 117200200,
                "planChannelId": 34280,
                "value": "com.xishanju.sprites.sy37",
                "file": null,
                "createTime": 1458005824000,
                "updateTime": 1458005824000,
                "latestUpdateUser": 1199,
                "planId": 2594,
                "channelId": "37wan",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 136200200,
                "planChannelId": 34281,
                "value": "com.xishanju.sprites.m4399",
                "file": null,
                "createTime": 1457954717000,
                "updateTime": 1457954717000,
                "latestUpdateUser": 1199,
                "planId": 2594,
                "channelId": "4399",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 105200600,
                "planChannelId": 34284,
                "value": "com.xishanju.sprites.am",
                "file": null,
                "createTime": 1457955961000,
                "updateTime": 1457955961000,
                "latestUpdateUser": 1199,
                "planId": 2594,
                "channelId": "amigo",
                "paramName": "packageName",
                "serverNumber": "v1"
            },
            {
                "paramId": 127200200,
                "planChannelId": 34329,
                "value": "21312",
                "file": null,
                "createTime": 1458197842000,
                "updateTime": 1458197842000,
                "latestUpdateUser": 1199,
                "planId": 2594,
                "channelId": "sogou",
                "paramName": "packageName",
                "serverNumber": "v1"
            }
        ],
        "platform": "ANDROID"
    },
    {
        "channelParamValues": [
          {
              "paramId": 105200600,
              "planChannelId": 34284,
              "value": "123456",
              "file": null,
              "createTime": 1457955961000,
              "updateTime": 1457955961000,
              "latestUpdateUser": 1199,
              "planId": 2594,
              "channelId": "amigo",
              "paramName": "packageName",
              "serverNumber": "v1"
          },
          {
              "paramId": 105200600,
              "planChannelId": 34284,
              "value": "654321",
              "file": null,
              "createTime": 1457955961000,
              "updateTime": 1457955961000,
              "latestUpdateUser": 1199,
              "planId": 2594,
              "channelId": "amigo",
              "paramName": "packageName",
              "serverNumber": "v1"
          }
        ],
        "platform": "IOS"
    }
]
```
