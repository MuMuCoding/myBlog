### response with 200

```js
//<response=200>
[ {
  "planChannelId" : 5,
  "downUrl" : "",
  "taskStatus" : "FAIL",
  "rechargeStatus" : "SUCCESS",
  "time" : 1438062751000,
  "channelId" : "kugou",
  "channelName" : "酷狗(Android)",
  "versionName" : "1.2.3"
}, {
  "planChannelId" : 4,
  "downUrl" : "",
  "taskStatus" : "FAIL",
  "rechargeStatus" : "FAIL",
  "time" : 1438062747000,
  "channelId" : "kugou",
  "channelName" : "酷狗(Android)",
  "versionName" : "2.1.1"
}, {
  "planChannelId" : 3,
  "downUrl" : "http://test.xgsdk.com:28080/sdk/mi/andriod-mi-4.3.4.zip",
  "taskStatus" : "FAIL",
  "rechargeStatus" : "SUCCESS",
  "time" : 1438062741000,
  "channelId" : "kugou",
  "channelName" : "酷狗(Android)",
  "versionName" : "1.0.1"
}, {
  "planChannelId" : 2,
  "downUrl" : "",
  "taskStatus" : "FAIL",
  "rechargeStatus" : "FAIL",
  "time" : 1438062738000,
  "channelId" : "oppo",
  "channelName" : "oppo(Android)",
  "versionName" : "2.0.2"
}, {
  "planChannelId" : 1,
  "downUrl" : "http://test.xgsdk.com:28080/sdk/mi/andriod-mi-4.3.4.zip",
  "taskStatus" : "FAIL",
  "rechargeStatus" : "SUCCESS",
  "time" : 1438062732000,
  "channelId" : "youlong",
  "channelName" : "游龙(Android)",
  "versionName" : "1.1.1"
} ]
```