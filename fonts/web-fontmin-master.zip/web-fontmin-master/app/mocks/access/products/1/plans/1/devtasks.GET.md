### response with 200

```js
//<response=200>
[
  {
    "channelId": "zhangyue",
    "channelName": "掌阅渠道",
    "versionNumber": "3.3.5",
    "buildNumber": "10001",
    "latestBuildNumber": "10002",
    "latestBuildDescription": "blblabalblalbl",
    "status":"NOT_READY",
    "comment": "",
    "extraUrl": "",
    "time": "2015-07-09 08:38:57"
  },
  {
    "channelId": "ios_91",
    "channelName": "91(iOS)渠道",
    "versionNumber": "5.1.2",
    "buildNumber": "10001",
    "latestBuildNumber": "10002",
    "latestBuildDescription": "blblabalblalbl",
    "status": "REQUESTED",
    "extraUrl": "",
    "comment": "需要提前上传至渠道进行初步审核",
    "time": "2015-07-09 08:38:57"
  },
  {
    "channelId": "android_xiaomi",
    "channelName": "小米市场",
    "versionNumber": "4.3.2",
    "buildNumber": "10001",
    "latestBuildNumber": "10002",
    "latestBuildDescription": "blblabalblalbl",
    "status": "PACKAGING",
    "extraUrl": "",
    "comment": "需要提前上传至渠道进行初步审核",
    "time": "2015-07-09 08:38:57"
  },
  {
    "channelId": "android_google_market",
    "channelName": "谷歌市场",
    "versionNumber": "4.3.5",
    "buildNumber": "10001",
    "latestBuildNumber": "10001",
    "latestBuildDescription": "blblabalblalbl",
    "status": "PACKAGE_SUCCESS",
    "extraUrl": "http://www.kingsoft.com/",
    "comment": "需要提前上传至渠道进行初步审核",
    "time": "2015-07-09 08:38:57"
  },
  {
    "channelId": "youlong",
    "channelName": "游龙",
    "versionNumber": "1.1.1",
    "buildNumber": "10001",
    "latestBuildNumber": "10002",
    "latestBuildDescription": "blblabalblalbl",
    "status": "TESTING",
    "extraUrl": "http://www.kingsoft.com/",
    "comment": "需要提前上传至渠道进行初步审核",
    "time": "2015-07-09 08:38:57"
  }
]
```