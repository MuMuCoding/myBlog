### request

```js
//<request>
[
  {
    "name": "appId",
    "alias": "appId",
    "value": "xxxxxxxxxx12"
  },
  {
    "name": "appSecret",
    "alias": "AppSecret",
    "value": "xgssgererwfsf"
  },
  {
    "name": "signature",
    "alias": "签名",
    "value": "xgssgererwfsf"
  },
  {
    "name": "packageName",
    "alias": "包名",
    "value": "com.xg.sdk"
  }
]

```


### response with 200

```js
//<response=200>

```
