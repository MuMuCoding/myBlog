
```js
//<request>

{
  processStatus: false,
  productId: 687,
  serviceName: 'DELTA_UPDATE',
  serviceStatus: true
}

```

### response with 200

```js
//<response=200>
// null
```
