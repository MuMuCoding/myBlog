### response with 200

```js
//<response=200>
{
  "require": {
    "icon": "oppo.icon~~~~~~~~~~",
    "splash": "oppo.splash~~~~~~~~~",
    "structure": "oppo.structure"
  }
}

```