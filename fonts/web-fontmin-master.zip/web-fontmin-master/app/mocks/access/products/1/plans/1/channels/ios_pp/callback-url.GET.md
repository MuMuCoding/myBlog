### response with 200

```js
//<response=200>
{
  "url": "this is mock callback url of zhangyue"
}
```