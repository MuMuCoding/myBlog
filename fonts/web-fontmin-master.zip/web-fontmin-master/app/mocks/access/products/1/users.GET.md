### response with 200

```js
//<response=200>
[
  {
    "id": 1,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "ADMIN"
  },
   {
    "id": 2,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "ADMIN"
  },
   {
    "id": 3,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "USER"
  },
   {
    "id": 4,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "USER"
  },
   {
    "id": 5,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "USER"
  },
   {
    "id": 45,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "USER"
  },
   {
    "id": 55,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "USER"
  },
   {
    "id": 65,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "USER"
  },
   {
    "id": 75,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "USER"
  },
   {
    "id": 85,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "USER"
  },
   {
    "id": 95,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "USER"
  }
]

```