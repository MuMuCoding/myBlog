### request

```js
//<request>
{
  "rechargeCallbackUrl": "wwww.xgsdk.com"
}

```

### response with 200

```js
//<response=200>

```
