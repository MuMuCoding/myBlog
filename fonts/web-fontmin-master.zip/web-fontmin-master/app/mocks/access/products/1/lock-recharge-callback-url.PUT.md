### request

```js
//<request>
{
  "isLock": true
}

```

### response with 200

```js
//<response=200>

```
