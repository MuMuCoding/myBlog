### request

```js
//<request>
// products/:productId/platforms/:platformId/packages
{
  "packageName": "com.xg.sdk"
}

```


### response with 200

```js
//<response=200>
// products/:productId/platforms/:platformId/packages

```
