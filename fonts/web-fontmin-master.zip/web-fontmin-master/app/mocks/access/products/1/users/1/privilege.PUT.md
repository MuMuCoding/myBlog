### request

```js
//<request>
{"role":"ADMIN"}
```

### response with 200

```js
//<response=200>
{"role":"ADMIN"}
```
