### response with 200

```js
//<response=200>
{
  "require": {
    "icon": "a blob",
    "splash": "91.splash~~~~~~~~~",
    "structure": "91.structure"
  }
}

```