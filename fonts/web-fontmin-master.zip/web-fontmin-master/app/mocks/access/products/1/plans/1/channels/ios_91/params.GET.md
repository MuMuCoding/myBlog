### response with 200

```js
//<response=200>
[
  {
    "id": 1,
    "name": "APP_ID",
    "type": "TEXT",
    "value": "ddddddddddddddddd",
    "description": null
  },
  {
    "id": 2,
    "name": "privateKey",
    "type": "TEXT",
    "value": null
  },
  {
    "id": 3,
    "name": "md5Key",
    "type": "OPTIONS",
    "options": ["abc", "cde"],
    "value": null
  },
  {
    "id": 4,
    "name": "MER_ID",
    "type": "FILE",
    "value": "test.jpg",
    "downloadUrl": "a blob"
  },
  {
    "id": 5,
    "name": "notifyGame",
    "type": "FILE",
    "value": null,
    "downloadUrl": null
  },
  {
    "id": 6,
    "name": "test",
    "type": "POPUP",
    "value": "{\"11111\":{\"name\":\"月卡\",\"code\":\"11107\",\"description\":\"有效期为60天\"},\"3\":{\"name\":\"大礼包\",\"code\":\"11108\",\"description\":\"很好的礼包\"}}",
    "downloadUrl": null
  },
  {
    "id": 7,
    "name": "支付币种",
    "type": "CCY_CFG",
    "value": null 
  }
]

```
