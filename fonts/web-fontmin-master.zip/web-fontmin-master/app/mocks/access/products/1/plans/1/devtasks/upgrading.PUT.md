### request

```js
//<request>
{
  "channelIds": ["youlong", "oppo"]
}
```

### response with 200

```js
//<response=200>

```
