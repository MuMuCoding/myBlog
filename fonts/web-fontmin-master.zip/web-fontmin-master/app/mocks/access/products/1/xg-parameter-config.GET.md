### response with 200

```js
//<response=200>
{
    "interfaceType":"NATIVE",
    "platform":"ANDROID",
    "xgAppId":2003,
    "appKey":"12234235342",
    "XgPlanId":2003,
    "XgPortalUrl":"www.baidu.com"
}
```