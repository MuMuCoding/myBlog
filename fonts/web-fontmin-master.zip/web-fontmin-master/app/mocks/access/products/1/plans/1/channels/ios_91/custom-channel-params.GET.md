### response with 200

```js
//<response=200>
[
  {
      "name": "USER_PARAM1",
      "value": "umengKey1",
      "description": "友盟Key1"
  },
  {
      "name": "USER_PARAM2",
      "value": "umengKey2",
      "description": "友盟Key2"
  },
  {
      "name": "USER_PARAM3",
      "value": "umengKey3",
      "description": "友盟Key3"
  },
  {
      "name": "USER_PARAM4",
      "value": "umengKey4",
      "description": "友盟Key4"
  },
  {
      "name": "USER_PARAM5",
      "value": "umengKey5",
      "description": "友盟Key5"
  },
    {
      "name": "USER_PARAM6",
      "value": "umengKey6",
      "description": "友盟Key6"
  },
  {
      "name": "USER_PARAM7",
      "value": "umengKey7",
      "description": "友盟Key7"
  },
  {
      "name": "USER_PARAM8",
      "value": "umengKey8",
      "description": "友盟Key8"
  },
  {
      "name": "USER_PARAM9",
      "value": "umengKey9",
      "description": "友盟Key9"
  },
  {
      "name": "USER_PARAM10",
      "value": "umengKey10",
      "description": "友盟Key10"
  }
]

```