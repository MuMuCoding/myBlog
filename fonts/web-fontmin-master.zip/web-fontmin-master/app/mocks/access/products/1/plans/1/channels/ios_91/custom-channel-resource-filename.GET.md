### response with 200

```js
//<response=200>
{
  "id": 1,
  "planId": 1,
  "channelId": "uc",
  "fileName": "",
  "file": null,
  "customResourceFileName": "custom_res.zip",
  "customResourceFile": null,
  "updateTime": 1444706564000
}

```