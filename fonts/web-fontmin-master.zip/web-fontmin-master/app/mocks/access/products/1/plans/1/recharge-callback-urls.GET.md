### response with 200

```js
//<response=200>
[
  {
    "channelId": "ios_91",
    "channelName": "91（ios）",
    "rechargeCallbackUrl": "wwww.xgsdk.com"
  },
  {
    "channelId": "360",
    "channelName": "360",
    "rechargeCallbackUrl": "wwww.xgsdk.com"
  },
  {
    "channelId": "kugou",
    "channelName": "酷狗",
    "rechargeCallbackUrl": "wwww.xgsdk.com"
  },
  {
    "channelId": "baidu",
    "channelName": "百度",
    "rechargeCallbackUrl": "wwww.xgsdk.com"
  }
]

```