### request

```js
//<request>
[
  {
    "id": 1,
    "name": "APP_ID",
    "type": "TEXT",
    "value": "1"
  },
  {
    "id": 2,
    "name": "privateKey",
    "type": "TEXT",
    "value": "2"
  },
  {
    "id": 3,
    "name": "md5Key",
    "type": "TEXT",
    "value": "3"
  },
  {
    "id": 4,
    "name": "MER_ID",
    "type": "TEXT",
    "value": "4"
  },
  {
    "id": 5,
    "name": "notifyGame",
    "type": "TEXT",
    "value": "5"
  }
]
```


### response with 200

```js
//<response=200>

```
