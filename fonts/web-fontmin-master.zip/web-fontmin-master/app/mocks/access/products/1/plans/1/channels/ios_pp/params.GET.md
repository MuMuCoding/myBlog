### response with 200

```js
//<response=200>
[
  {
    "id": 1,
    "name": "userName",
    "type": "TEXT",
    "alias": "userName",
    "value": "232323",
    "pattern": "\u005e\u005b\u005c\u0075\u0034\u0065\u0030\u0030\u002d\u005c\u0075\u0039\u0066\u0061\u0035\u005d\u007b\u0030\u002c\u007d\u0024",
    "description": "只能为中文只能为中文只能为中文只能为中文只能为中文只能为中文只能为中文只能为中文只能为中文只能为中文只能为中文只能为中文"
  },
  {
    "id": 2,
    "name": "privateKey",
    "type": "TEXT",
    "value": null,
    "alias": "私钥",
    "pattern": "^[A-Za-z0-9_-]{4}$",
    "description": "只能输入三个字符"
  },
  {
    "id": 3,
    "name": "md5Key",
    "type": "TEXT",
    "value": null,
    "alias": "加密方式",
    "pattern": "",
    "description": ""
  },
  {
    "id": 4,
    "name": "MER_ID",
    "paramDesc": "商户ID",
    "type": "TEXT",
    "alias": "mer id",
    "value": null,
    "pattern": "\u005e\u005b\u0030\u002d\u0039\u005d\u002a\u0024",
    "description": "只能输入数字"
  },
  {
    "id": 898942498,
    "name": "notifyGame",
    "paramDesc": "游戏充值通知地址",
    "type": "TEXT",
    "alias": "98结尾",
    "value": null,
    "pattern": "\u005e\u005b\u0030\u002d\u0039\u005d\u002a\u0024",
    "description": "只能输入数字"
  }
]

```