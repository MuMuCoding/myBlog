### response with 200

```js
//<response=200>
{
  "require": {
    "icon": "kugou.icon~~~~~~~~~~",
    "splash": "kugou.splash~~~~~~~~~",
    "structure": "kugou.structure"
  }
}

```