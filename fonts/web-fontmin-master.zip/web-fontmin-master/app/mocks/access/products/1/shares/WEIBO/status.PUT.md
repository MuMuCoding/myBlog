### request

```js
//<request>
{
  "enabled": "YES"
}

```

### response with 200

```js
//<response=200>

```
