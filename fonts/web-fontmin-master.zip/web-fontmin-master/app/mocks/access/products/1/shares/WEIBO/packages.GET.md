### response with 200

```js
//<response=200>
[
  {
    "packageName": "微博"
  },
  {
    "packageName": "com.google.bbb"
  },
  {
    "packageName": "com.tencent.ccc"
  }
]

```
