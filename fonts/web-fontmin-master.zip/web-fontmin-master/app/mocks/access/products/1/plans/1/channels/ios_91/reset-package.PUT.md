### response with 200

```js
//<response=200>
{"data":"reset success"}
```