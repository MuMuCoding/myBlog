### request

```js
//<request>
[
  {
    "id": 1,
    "name": "APP_ID",
    "type": "TEXT",
    "value": "1"
  },
  {
    "id": 2,
    "name": "privateKey",
    "type": "TEXT",
    "value": "2"
  },
  {
    "id": 3,
    "name": "md5Key",
    "type": "OPTIONS",
    "value": "cde"
  },
  {
    "id": 4,
    "name": "MER_ID",
    "type": "FILE",
    "value": null
  },
  {
    "id": 5,
    "name": "notifyGame",
    "type": "FILE",
    "value": null
  }
]
```

### response with 200

```js
//<response=200>

```
