### response with 200

```js
//<response=200>
// /products/:productId/platforms

[
  {
    "platformId": "WEIXIN",
    "platformName": "微信",
    "dimension": "PACKAGE",
    "enabled": "YES"
  },
  {
    "platformId": "WEIBO",
    "platformName": "微博",
    "dimension": "PACKAGE",
    "enabled": "YES"
  },
  {
    "platformId": "QQ",
    "platformName": "QQ",
    "dimension": "PRODUCT",
    "enabled": "NO"
  }
]

```