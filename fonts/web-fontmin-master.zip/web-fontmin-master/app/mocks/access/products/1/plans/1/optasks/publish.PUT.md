### request

```js
//<request>
{
  "channelId": ["google market"]
}
```

### response with 200

```js
//<response=200>

```
