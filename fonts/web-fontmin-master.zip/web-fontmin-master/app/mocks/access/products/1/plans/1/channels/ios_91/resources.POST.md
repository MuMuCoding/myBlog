### response with 200

```js
//<response=200>
{}

```