### request

```js
//<request>
{
  "channelId": "360",
  "channelVersion": "1.0.1",
  "releaseTime": "20150406",
  "qq": "154433456",
  "phone": "18576768373",
  "comment": "啥啥啥"
}

```


### response with 200

```js
//<response=200>

```
