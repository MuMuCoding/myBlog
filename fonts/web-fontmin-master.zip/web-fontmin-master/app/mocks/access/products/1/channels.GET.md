### response with 200

```js
//<response=200>
[
  {
    "channelId": "91_ANDROID",
    "channelName": "91(Android)",
    "versions": [
      "1.1.3",
      "1.1.2",
      "1.1.1"
    ],
    "deprecated": ["1.1.3"]
  },
  {
    "channelId": "kugou_ANDROID",
    "channelName": "酷狗(Android)",
    "versions": [
      "1.0.5",
      "1.0.4",
      "1.0.3"
    ],
    "deprecated": ["1.0.3"]
  },
  {
    "versions": [
      "1.0.2",
      "1.0.1"
    ],
    "deprecated": ["1.0.1"],
    "channelId": "oppo_ANDROID",
    "channelName": "oppo(Android)"
  },
  {
    "versions": [
      "1.0.4",
      "1.0.3",
      "1.0.2",
      "1.0.1"
    ],
    "deprecated": ["1.0.1", "1.0.4"],
    "channelId": "pps_ANDROID",
    "channelName": "pps(Android)"
  },
  {
    "versions": [
      "1.0.3",
      "1.0.2"
    ],
    "deprecated": ["1.0.3"],
    "channelId": "zhangqu_ANDROID",
    "channelName": "掌趣(Android)"
  },
  {
    "versions": [
      "1.0.6"
    ],
    "deprecated": [],
    "channelId": "zhangyue_ANDROID",
    "channelName": "掌阅(Android)"
  },
  {
    "channelId": "360_IOS",
    "channelName": "360(IOS)",
    "versions": [
      "1.0.6"
    ],
    "deprecated": []
  }
]

```