### request

```js
//<request>
{"email":"1013732827@qq.com"}
```

### response with 200

```js
//<response=200>

```
