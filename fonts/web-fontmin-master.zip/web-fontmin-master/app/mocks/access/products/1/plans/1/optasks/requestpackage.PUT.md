### request

```js
//<request>
{
  "channelIds":["ios_91","google market","youlong"],
  "comment": "需要提前上传至渠道进行初步审核"
}

```


### response with 200

```js
//<response=200>
{
  "channelIds":["ios_91","google market","youlong"],
  "comment": "需要提前上传至渠道进行初步审核"
}

```
