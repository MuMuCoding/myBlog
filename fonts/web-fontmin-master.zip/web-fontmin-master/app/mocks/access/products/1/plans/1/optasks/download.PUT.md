### request

```js
//<request>
{
  "channelId": "youlong"
}

```