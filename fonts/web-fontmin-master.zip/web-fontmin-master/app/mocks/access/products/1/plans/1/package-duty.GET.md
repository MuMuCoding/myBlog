### response with 200

```js
//<response=200>
[
  {
    "channelId": "360",
    "channelName": "112222222",
    "versionName": "3.3.5",
    "time": "2015-06-20",
    "status":{
      "packagestatus": 0,
      "readystatus": [0, 1, 1, 0],
      "grounding": 0
    }
  },
  {
    "channelId": "360",
    "channelName": "啥22222",
    "versionName": "3.3.5",
    "time": "2015-06-20",
    "status":{
      "packagestatus": 1,
      "grounding": 1
    }
  },
  {
    "channelId": "360",
    "channelName": "嘿嘿",
    "versionName": "3.3.5",
    "time": "2015-06-20",
    "status":{
      "packagestatus": 0,
      "readystatus": [1, 1, 1, 0],
      "grounding": 0
    }
  },
  {
    "channelId": "360",
    "channelName": "2222222222222",
    "versionName": "3.3.5",
    "time": "2015-06-20",
    "status":{
      "packagestatus": 2,
      "grounding": 2
    }
  }
]
```