### request

```js
//<request>
{
  "name": "xht计划",
  "deadline": "20150908",
  "channels": [
    {
      "channelId": "ios_91",
      "channelVersionNumber": "1.0.3"
    },
    {
      "channelId": "ios_aisi",
      "channelVersionNumber": "1.1.5"
    }
  ]
}
```

### response with 200

```js
//<response=200>

```
