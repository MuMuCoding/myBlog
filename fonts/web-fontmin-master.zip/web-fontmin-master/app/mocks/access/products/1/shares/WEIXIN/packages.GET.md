### response with 200

```js
//<response=200>
[
  {
    "packageName": "微信"
  },
  {
    "packageName": "com.google.keep"
  },
  {
    "packageName": "com.tencent.weixin"
  }
]

```
