### response with 200

```js
//<response=200>
[{
  "channelId": "zhangyue",
  "channelName": "掌阅渠道",
  "versionNumber": "3.3.5",
  "status": {
    "NOT_READY": [
      1,
      0,
      0,
      1
    ]
  },
  "extraUrl": "",
  "time": "2015-07-09 08:38:57.795"
}, {
  "channelId": "ios_91",
  "channelName": "91(iOS)渠道",
  "versionNumber": "5.1.2",
  "status": "READY",
  "extraUrl": "",
  "time": "2015-07-09 08:38:57.795"
}, {
  "channelId": "xiaomi market",
  "channelName": "小米市场",
  "versionNumber": "4.3.2",
  "status": "REQUESTED",
  "extraUrl": "",
  "time": "2015-07-09 08:38:57.795"
}, {
  "channelId": "google market",
  "channelName": "谷歌市场",
  "versionNumber": "4.3.5",
  "status": "TESTED",
  "extraUrl": "http://www.kingsoft.com/",
  "time": "2015-07-09 08:38:57.795"
}, {
  "channelId": "youlong",
  "channelName": "游龙",
  "versionNumber": "1.1.1",
  "status": "PUBLISHED",
  "extraUrl": "http://www.kingsoft.com/",
  "time": "2015-07-09 08:38:57.795"
}]

```