### request

```js
//<request>
{
  "id": 1,
  "name": "����������",
  "orientation": "HORIZONTAL",
  "signatureFileName": "8fdna02nf309fdksafnabr3320fdnakf",
  "interfaceType": "COCOS2D",
  "icon": "multipartFile",
  "ios": false,
  "android": true,
  "type": "RPG,ACT"
}

```

### response with 200

```js
//<response=200>

```
