### request

```js
//<request>
{
  "rechargeCallbackUrl": "www.kingsosssssssssft.com"
}

```

### response with 200

```js
//<response=200>

```
