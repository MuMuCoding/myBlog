### response with 200

```js
//<response=200>
[
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"},
  {"productId":1,"warseId":"11111","name":"abc","paidAmount":600,"gameCoin":60,"description":"hello, aaaaa"}

]
```
