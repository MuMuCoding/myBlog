### response with 200

``` js
//<request>
{
  appId: '111'
}
```

```js
//<response=200>
[
  {
    "id": 1,
    "platform": "ANDROID",
    "roles": ["OWNER"],
    "type": "ACT,SLG",
    "name": "变身吧主公",
    "appId": "1"
  },
  {
    "id": 2,
    "platform": "IOS",
    "roles": ["ADMIN"],
    "type": "CAG",
    "name": "hello world",
    "appId": "1"
  }
]

```
