### response with 200

```js
//<response=200>

[
    {
        "id": 34,
        "region": "瑞士",
        "currencyCode": "CHF",
        "currencyName": "法郎",
        "createTime": 1450343830000
    },
    {
        "id": 38,
        "region": "香港",
        "currencyCode": "HKD",
        "currencyName": "港币",
        "createTime": 1450343830000
    },
    {
        "id": 39,
        "region": "台湾",
        "currencyCode": "TWD",
        "currencyName": "台币",
        "createTime": 1450343830000
    },
    {
        "id": 47,
        "region": "阿拉伯联合酋长国",
        "currencyCode": "AED",
        "currencyName": "迪拉姆",
        "createTime": 1450343830000
    },
    {
        "id": 4,
        "region": "墨西哥",
        "currencyCode": "MXN",
        "currencyName": "墨西哥比索",
        "createTime": 1450343829000
    },
    {
        "id": 7,
        "region": "塞浦路斯,爱沙尼亚,匈牙利,荷兰,立陶宛,希腊,斯洛伐克,奥地利,芬兰,德国,波兰,马耳他,葡萄牙,罗马尼亚,捷克共和国,斯洛文尼亚,拉脱维亚,法国,西班牙,意大利,爱尔兰,保加利亚,比利时,卢森堡",
        "currencyCode": "EUR",
        "currencyName": "欧元",
        "createTime": 1450343829000
    },
    {
        "id": 32,
        "region": "丹麦",
        "currencyCode": "DKK",
        "currencyName": "克朗",
        "createTime": 1450343830000
    },
    {
        "id": 44,
        "region": "沙特阿拉伯",
        "currencyCode": "SAR",
        "currencyName": "里亚尔",
        "createTime": 1450343830000
    },
    {
        "id": 2,
        "region": "美国,韩国",
        "currencyCode": "USD",
        "currencyName": "美元",
        "createTime": 1450343829000
    },
    {
        "id": 5,
        "region": "加拿大",
        "currencyCode": "CAD",
        "currencyName": "加拿大元",
        "createTime": 1450343829000
    },
    {
        "id": 45,
        "region": "南非",
        "currencyCode": "ZAR",
        "currencyName": "南非兰特",
        "createTime": 1450343830000
    },
    {
        "id": 33,
        "region": "挪威",
        "currencyCode": "NOK",
        "currencyName": "克朗",
        "createTime": 1450343830000
    },
    {
        "id": 40,
        "region": "印度",
        "currencyCode": "INR",
        "currencyName": "卢比",
        "createTime": 1450343830000
    },
    {
        "id": 1,
        "region": "中国",
        "currencyCode": "CNY",
        "currencyName": "人民币",
        "createTime": 1450343829000
    },
    {
        "id": 35,
        "region": "澳大利亚",
        "currencyCode": "AUD",
        "currencyName": "澳元",
        "createTime": 1450343830000
    },
    {
        "id": 42,
        "region": "以色列",
        "currencyCode": "ILS",
        "currencyName": "新谢克尔",
        "createTime": 1450343830000
    },
    {
        "id": 48,
        "region": "新加坡",
        "currencyCode": "SGD",
        "currencyName": "新加坡元",
        "createTime": 1450343831000
    },
    {
        "id": 37,
        "region": "日本",
        "currencyCode": "JPY",
        "currencyName": "日元",
        "createTime": 1450343830000
    },
    {
        "id": 6,
        "region": "英国",
        "currencyCode": "GBP",
        "currencyName": "英镑",
        "createTime": 1450343829000
    },
    {
        "id": 41,
        "region": "印度尼西亚",
        "currencyCode": "IDR",
        "currencyName": "盾",
        "createTime": 1450343830000
    },
    {
        "id": 31,
        "region": "瑞典",
        "currencyCode": "SEK",
        "currencyName": "克朗",
        "createTime": 1450343830000
    },
    {
        "id": 36,
        "region": "新西兰",
        "currencyCode": "NZD",
        "currencyName": "新西兰币",
        "createTime": 1450343830000
    },
    {
        "id": 46,
        "region": "土耳其",
        "currencyCode": "TRY",
        "currencyName": "新里拉",
        "createTime": 1450343830000
    },
    {
        "id": 43,
        "region": "俄罗斯",
        "currencyCode": "RUB",
        "currencyName": "卢布",
        "createTime": 1450343830000
    }
]

```
