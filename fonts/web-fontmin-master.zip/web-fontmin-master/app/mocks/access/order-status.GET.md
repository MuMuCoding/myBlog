### response with 200

```js
//<response=200>
[
  {
    "status": 2,
    "text": "成功"
  },
  {
    "status": 5,
    "text": "游戏拒绝"
  },
  {
    "status": -2,
    "text": "其他"
  }
]
```