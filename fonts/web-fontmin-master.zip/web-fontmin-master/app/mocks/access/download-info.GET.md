### response with 200

```js
//<response=200>
{
  "apiJava": {
      "url": "/index.html",
      "version": "2.0.1",
      "date": "2015-11-08",
      "description": "啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥"
  },
  "apiCocos": {
      "url": "/index.html",
      "version": "2.0.1",
      "date": "2015-11-08"
  },
  "apiUnity": {
      "url": "/index.html",
      "version": "2.0.1",
      "date": "2015-11-08"
  },
  "apiObjectC": {
      "url": "/index.html",
      "version": "2.0.1",
      "date": "2015-11-08"
  },
  "packageAndroid": {
     "windows": {
        "url": "/index.html",
        "version": "2.0.1",
        "date": "2015-11-08 14:32:47"
      },
      "mac": {
      	"url": "/index.html",
      	"version": "2.0.1",
      	"date": "2015-11-08 14:32:47"
      }
  },
  "packageIos": [
    {
      "channelId": "1er",
      "channelName": "什么双方都",
      "url": "/index.html",
      "version": "2.0.1",
      "date": "2015-11-08 14:32:47"
    },
    {
      "channelId": "2334",
      "channelName": "单方事故",
      "url": "/index.html",
      "version": "2.0.31",
      "date": "205-11-08 14:32:47"
    },
    {
      "channelId": "23",
      "channelName": "feryd为",
      "url": "/index.html",
      "version": "2.0.343",
      "date": "2015-1-08 14:32:47"
    },
  ],
  "demoServer": {
    "url": "/index.html",
    "version": "2.0.1",
    "date": "2015-11-0 14:32:47"
  }
}

```
