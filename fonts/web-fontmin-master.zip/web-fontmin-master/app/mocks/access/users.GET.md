### request

```js
//<request>
{"email": "1111"}

```

### response with 200

```js
//<response=200>
[
  {
    "id": 1,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "aaaa@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "ADMIN"
  },
   {
    "id": 2,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "bbbb@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  },
   {
    "id": 3,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "ccccc@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  },
   {
    "id": 4,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "ccc@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  },
   {
    "id": 5,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  },
   {
    "id": 45,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "abcddsf@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  },
   {
    "id": 55,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "sfsfsf@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  },
   {
    "id": 65,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  },
   {
    "id": 75,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  },
   {
    "id": 85,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  },
   {
    "id": 95,
    "name": "刘德华",
    "phone": "15521311976",
    "email": "10137228@qq.com",
    "qq": "44114141414",
    "avatar": "/img/xyfm.jpg",
    "role":  "NORMAL"
  }
]

```
