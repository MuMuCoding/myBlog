### response with 200

```js
//<response=200>
[
  {
    "code": 1001,
    "event": "创建发布计划"
  },
  {
    "code": 1002,
    "event": "修改发布计划"
  },
  {
    "code": 1003,
    "event": "归档发布计划"
  },
  {
    "code": 2001,
    "event": "开发接入SDK"
  },
  {
    "code": 3001,
    "event": "配置渠道参数"
  },
  {
    "code": 4002,
    "event": "配置充值回调"
  },
  {
    "code": 5002,
    "event": "图标工具"
  },
  {
    "code": 6001,
    "event": "创建游戏"
  },
  {
    "code": 6002,
    "event": "修改游戏"
  },
  {
    "code": 6003,
    "event": "删除游戏"
  },
  {
    "code": 7001,
    "event": "添加用户"
  },
  {
    "code": 7002,
    "event": "移除用户"
  }
]
```