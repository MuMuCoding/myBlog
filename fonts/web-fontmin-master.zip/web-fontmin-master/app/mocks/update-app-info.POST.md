# 获取游戏信息

### request

```js
//<request>
{
  type: 'get-user',
  requestSystem: 'sdkportal',
  ts: '20150723150028',
  accessToken: 'xxxx',
  sign: 'xxxx',
  appId: '1',
  appName: '西游降魔',
  appDesc: 'xxxxx',
  appType: 'RPG,CAG',
  iconUrl: 'https://striker.teambition.net/thumbnail/110b052ab868643d907036cd3ae9e670bfb6/w/200/h/200'
}

```

### response with 200

```js

//<response=200>
{
  code: 0,
  msg: 'xxx'
}


```
