### response with 200

```js
//<response=200>
[
  {
    "serverId": "server1",
    "serverName": "Server 1"
  },
  {
    "serverId": "server2",
    "serverName": "Server 2"
  },
  {
    "serverId": "server3",
    "serverName": "Server 3"
  },
  {
    "serverId": "server4",
    "serverName": "Server 4"
  },
  {
    "serverId": "server5",
    "serverName": "Server 5"
  }
]
```