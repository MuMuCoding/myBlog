### response with 200

```js
//<response=200>
[
  {
    "channelId": "91_ANDROID",
    "channelName": "91(Android)"
  },
  {
    "channelId": "mi",
    "channelName": "小米"
  },
  {
    "channelId": "07073",
    "channelName": "07073"
  },
  {
    "channelId": "huawei",
    "channelName": "huawei"
  },
  {
    "channelId": "yingyongbao",
    "channelName": "应用宝"
  }
]
```