### response with 200

```js
//<response=200>
[
  {
    "tdate": "2015-11-01",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-02",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-03",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-04",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-05",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-06",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-07",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-08",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-09",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-10",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-11",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  },
  {
    "tdate": "2015-11-12",
    "newDeviceIdcnt": 192,
    "newAccountIdcnt": 193,
    "activeAccountIdcnt": 324,
    "recharge": 324234,
    "rechargeAccountIdcnt": 2341,
    "arpu": 1.2
  }
]
```