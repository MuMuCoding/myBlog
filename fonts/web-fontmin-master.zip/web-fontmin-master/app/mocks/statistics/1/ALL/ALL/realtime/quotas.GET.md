### response with 200

```js
//<response=200>
{
  "today": {
    "activeDeviceIdcnt": 132,
    "activeAccountIdcnt": 12484,
    "newAccountIdcnt": 130,
    "recharge": 129875,
    "rechargeAccountIdcnt": 927,
    "rechargeCnt": 1234
  }
}

```
