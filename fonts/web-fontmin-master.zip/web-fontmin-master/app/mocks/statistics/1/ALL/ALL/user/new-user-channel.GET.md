### response with 200

```js
//<response=200>
//"/statistics/:appId/:channelId/:serverId/user/new-user-area", {
//  start: '2015-11-08',
//  to: '2015-11-09'
//}

[{
  "channelId": "mi1xxx",
  "newAccountIdcnt": 9,
  "percentage": 0.823
}, {
  "channelId": "百度2",
  "newAccountIdcnt": 58,
  "percentage": 0.757
}, {
  "channelId": "百度3",
  "newAccountIdcnt": 88,
  "percentage": 0.757
}, {
  "channelId": "mi4",
  "newAccountIdcnt": 89,
  "percentage": 0.823
}, {
  "channelId": "百度5",
  "newAccountIdcnt": 88,
  "percentage": 0.757
}, {
  "channelId": "百度6",
  "newAccountIdcnt": 88,
  "percentage": 0.757
}, {
  "channelId": "mi7",
  "newAccountIdcnt": 99,
  "percentage": 0.823
}, {
  "channelId": "百度8",
  "newAccountIdcnt": 88,
  "percentage": 0.757
}, {
  "channelId": "百度9",
  "newAccountIdcnt": 88,
  "percentage": 0.757
},
{
  "channelId": "百度10",
  "newAccountIdcnt": 88,
  "percentage": 0.757
},
{
  "channelId": "百度12",
  "newAccountIdcnt": 88,
  "percentage": 0.757
},
{
  "channelId": "百度13",
  "newAccountIdcnt": 68,
  "percentage": 0.757
},
{
  "channelId": "百度14",
  "newAccountIdcnt": 48,
  "percentage": 0.457
}
]

```