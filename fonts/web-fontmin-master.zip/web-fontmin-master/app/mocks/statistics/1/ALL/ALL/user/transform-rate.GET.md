### response with 199

```js
//<response=200>

[{"tdate":"2016-02-09","accountLoginDeviceTransformRate":0.8866,"roleLoginDeviceTransformRate":1.0000,"roleLoginAccountTransformRate":1.0000},{"tdate":"2016-02-10","accountLoginDeviceTransformRate":0.8851,"roleLoginDeviceTransformRate":1.0000,"roleLoginAccountTransformRate":1.0000},{"tdate":"2016-02-11","accountLoginDeviceTransformRate":0.8783,"roleLoginDeviceTransformRate":1.0000,"roleLoginAccountTransformRate":1.0000},{"tdate":"2016-02-12","accountLoginDeviceTransformRate":0.8783,"roleLoginDeviceTransformRate":1.0000,"roleLoginAccountTransformRate":1.0000},{"tdate":"2016-02-13","accountLoginDeviceTransformRate":0.9073,"roleLoginDeviceTransformRate":1.0000,"roleLoginAccountTransformRate":1.0000},{"tdate":"2016-02-14","accountLoginDeviceTransformRate":0.8991,"roleLoginDeviceTransformRate":1.0000,"roleLoginAccountTransformRate":1.0000},{"tdate":"2016-02-15","accountLoginDeviceTransformRate":0.9100,"roleLoginDeviceTransformRate":1.0000,"roleLoginAccountTransformRate":1.0000}]

```
