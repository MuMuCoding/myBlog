### response with 200

```js
//<response=200>
[
  {
    "channelId": "mi",
    "pur": 0.34
  },
  {
    "channelId": "mi1",
    "pur": 0.25
  },
  {
    "channelId": "mi2",
    "pur": 0.76
  },
  {
    "channelId": "mi3",
    "pur": 0.41
  },
  {
    "channelId": "mi4",
    "pur": 0.38
  },
  {
    "channelId": "mi5",
    "pur": 0.16
  },
  {
    "channelId": "mi6",
    "pur": 0.42
  },
  {
    "channelId": "mi7",
    "pur": 0.14
  },
  {
    "channelId": "mi8",
    "pur": 0.34
  },
  {
    "channelId": "mi9",
    "pur": 0.24
  },
  {
    "channelId": "mi10",
    "pur": 0.31
  },
  {
    "channelId": "mi11",
    "pur": 0.41
  }
]
```