### response with 200

```js
//<response=200>
[
  {
    "time": "00:00",
    "value": 89
  },
  {
    "time": "00:05",
    "value": 99
  },
  {
    "time": "00:10",
    "value": 89
  },
  {
    "time": "00:15",
    "value": 124
  },
  {
    "time": "00:20",
    "value": 89
  },
  {
    "time": "00:25",
    "value": 99
  },
  {
    "time": "00:30",
    "value": 89
  },
  {
    "time": "00:35",
    "value": 99
  },
  {
    "time": "00:40",
    "value": 424
  },
  {
    "time": "00:45",
    "value": 99
  },
  {
    "time": "00:50",
    "value": 89
  },
  {
    "time": "00:55",
    "value": 99
  },
  {
    "time": "01:00",
    "value": 89
  },
  {
    "time": "01:05",
    "value": 245
  },
  {
    "time": "01:10",
    "value": 89
  },
  {
    "time": "01:15",
    "value": 99
  },
  {
    "time": "01:20",
    "value": 89
  },
  {
    "time": "01:25",
    "value": 452
  },
  {
    "time": "01:30",
    "value": 89
  },
  {
    "time": "01:35",
    "value": 785
  },
  {
    "time": "01:40",
    "value": 89
  },
  {
    "time": "01:45",
    "value": 99
  },
  {
    "time": "01:50",
    "value": 425
  },
  {
    "time": "01:55",
    "value": 99
  },
  {
    "time": "02:00",
    "value": 89
  },
  {
    "time": "02:05",
    "value": 99
  },
  {
    "time": "02:10",
    "value": 89
  },
  {
    "time": "02:15",
    "value": 243
  },
  {
    "time": "02:20",
    "value": 6453
  },
  {
    "time": "02:25",
    "value": 99
  },
  {
    "time": "02:30",
    "value": 89
  },
  {
    "time": "02:35",
    "value": 99
  },
  {
    "time": "02:40",
    "value": 324
  },
  {
    "time": "02:45",
    "value": 99
  },
  {
    "time": "02:50",
    "value": 645
  },
  {
    "time": "02:55",
    "value": 99
  },
  {
    "time": "03:00",
    "value": 89
  },
  {
    "time": "03:05",
    "value": 99
  },
  {
    "time": "03:10",
    "value": 89
  },
  {
    "time": "03:15",
    "value": 99
  },
  {
    "time": "03:20",
    "value": 89
  },
  {
    "time": "03:25",
    "value": 99
  },
  {
    "time": "03:30",
    "value": 89
  },
  {
    "time": "03:35",
    "value": 99
  },
  {
    "time": "03:40",
    "value": 89
  },
  {
    "time": "03:45",
    "value": 99
  },
  {
    "time": "03:50",
    "value": 243
  },
  {
    "time": "03:55",
    "value": 99
  },
  {
    "time": "04:00",
    "value": 89
  },
  {
    "time": "04:05",
    "value": 99
  },
  {
    "time": "04:10",
    "value": 89
  },
  {
    "time": "04:15",
    "value": 99
  },
  {
    "time": "04:20",
    "value": 89
  },
  {
    "time": "04:25",
    "value": 99
  },
  {
    "time": "04:30",
    "value": 456
  },
  {
    "time": "04:35",
    "value": 99
  },
  {
    "time": "04:40",
    "value": 89
  },
  {
    "time": "04:45",
    "value": 99
  },
  {
    "time": "04:50",
    "value": 453
  },
  {
    "time": "04:55",
    "value": 99
  },
  {
    "time": "05:00",
    "value": 89
  },
  {
    "time": "05:05",
    "value": 99
  },
  {
    "time": "05:10",
    "value": 89
  },
  {
    "time": "05:15",
    "value": 99
  },
  {
    "time": "05:20",
    "value": 346
  },
  {
    "time": "05:25",
    "value": 99
  },
  {
    "time": "05:30",
    "value": 89
  },
  {
    "time": "05:35",
    "value": 99
  },
  {
    "time": "05:40",
    "value": 89
  },
  {
    "time": "05:45",
    "value": 99
  },
  {
    "time": "05:50",
    "value": 89
  },
  {
    "time": "05:55",
    "value": 99
  },
  {
    "time": "06:00",
    "value": 89
  },
  {
    "time": "06:05",
    "value": 99
  },
  {
    "time": "06:10",
    "value": 89
  },
  {
    "time": "06:15",
    "value": 99
  },
  {
    "time": "06:20",
    "value": 765
  },
  {
    "time": "06:25",
    "value": 99
  },
  {
    "time": "06:30",
    "value": 89
  },
  {
    "time": "06:35",
    "value": 99
  },
  {
    "time": "06:40",
    "value": 89
  },
  {
    "time": "06:45",
    "value": 99
  },
  {
    "time": "06:50",
    "value": 89
  },
  {
    "time": "06:55",
    "value": 99
  },
  {
    "time": "07:00",
    "value": 456
  },
  {
    "time": "07:05",
    "value": 99
  },
  {
    "time": "07:10",
    "value": 89
  },
  {
    "time": "07:15",
    "value": 99
  },
  {
    "time": "07:20",
    "value": 89
  },
  {
    "time": "07:25",
    "value": 99
  },
  {
    "time": "07:30",
    "value": 89
  },
  {
    "time": "07:35",
    "value": 99
  },
  {
    "time": "07:40",
    "value": 89
  },
  {
    "time": "07:45",
    "value": 99
  },
  {
    "time": "07:50",
    "value": 89
  },
  {
    "time": "07:55",
    "value": 3896
  },
  {
    "time": "08:00",
    "value": 89
  },
  {
    "time": "08:05",
    "value": 99
  },
  {
    "time": "08:10",
    "value": 89
  },
  {
    "time": "08:15",
    "value": 99
  },
  {
    "time": "08:20",
    "value": 89
  },
  {
    "time": "08:25",
    "value": 99
  },
  {
    "time": "08:30",
    "value": 89
  },
  {
    "time": "08:35",
    "value": 99
  },
  {
    "time": "08:40",
    "value": 89
  },
  {
    "time": "08:45",
    "value": 99
  },
  {
    "time": "08:50",
    "value": 89
  },
  {
    "time": "08:55",
    "value": 99
  },
  {
    "time": "09:00",
    "value": 89
  },
  {
    "time": "09:05",
    "value": 99
  },
  {
    "time": "09:10",
    "value": 89
  },
  {
    "time": "09:15",
    "value": 99
  },
  {
    "time": "09:20",
    "value": 89
  },
  {
    "time": "09:25",
    "value": 99
  },
  {
    "time": "09:30",
    "value": 3745
  },
  {
    "time": "09:35",
    "value": 99
  },
  {
    "time": "09:40",
    "value": 89
  },
  {
    "time": "09:45",
    "value": 99
  },
  {
    "time": "09:50",
    "value": 89
  },
  {
    "time": "09:55",
    "value": 99
  },
  {
    "time": "10:00",
    "value": 89
  },
  {
    "time": "10:05",
    "value": 99
  },
  {
    "time": "10:10",
    "value": 89
  },
  {
    "time": "10:15",
    "value": 99
  },
  {
    "time": "10:20",
    "value": 89
  },
  {
    "time": "10:25",
    "value": 99
  },
  {
    "time": "10:30",
    "value": 89
  },
  {
    "time": "10:35",
    "value": 99
  },
  {
    "time": "10:40",
    "value": 89
  },
  {
    "time": "10:45",
    "value": 8764
  },
  {
    "time": "10:50",
    "value": 89
  },
  {
    "time": "10:55",
    "value": 99
  },
  {
    "time": "11:00",
    "value": 89
  },
  {
    "time": "11:05",
    "value": 99
  },
  {
    "time": "11:10",
    "value": 89
  },
  {
    "time": "11:15",
    "value": 99
  },
  {
    "time": "11:20",
    "value": 89
  },
  {
    "time": "11:25",
    "value": 99
  },
  {
    "time": "11:30",
    "value": 89
  },
  {
    "time": "11:35",
    "value": 99
  },
  {
    "time": "11:40",
    "value": 89
  },
  {
    "time": "11:45",
    "value": 99
  },
  {
    "time": "11:50",
    "value": 89
  },
  {
    "time": "11:55",
    "value": 99
  },
  {
    "time": "12:00",
    "value": 89
  },
  {
    "time": "12:05",
    "value": 456
  },
  {
    "time": "12:10",
    "value": 89
  },
  {
    "time": "12:15",
    "value": 99
  },
  {
    "time": "12:20",
    "value": 89
  },
  {
    "time": "12:25",
    "value": 99
  },
  {
    "time": "12:30",
    "value": 89
  },
  {
    "time": "12:35",
    "value": 99
  },
  {
    "time": "12:40",
    "value": 89
  },
  {
    "time": "12:45",
    "value": 99
  },
  {
    "time": "12:50",
    "value": 89
  },
  {
    "time": "12:55",
    "value": 99
  },
  {
    "time": "13:00",
    "value": 89
  },
  {
    "time": "13:05",
    "value": 3745
  },
  {
    "time": "13:10",
    "value": 89
  },
  {
    "time": "13:15",
    "value": 99
  },
  {
    "time": "13:20",
    "value": 89
  },
  {
    "time": "13:25",
    "value": 99
  },
  {
    "time": "13:30",
    "value": 89
  },
  {
    "time": "13:35",
    "value": 99
  },
  {
    "time": "13:40",
    "value": 89
  },
  {
    "time": "13:45",
    "value": 99
  },
  {
    "time": "13:50",
    "value": 765
  },
  {
    "time": "13:55",
    "value": 99
  },
  {
    "time": "14:00",
    "value": 89
  },
  {
    "time": "14:05",
    "value": 99
  },
  {
    "time": "14:10",
    "value": 5876
  },
  {
    "time": "14:15",
    "value": 99
  },
  {
    "time": "14:20",
    "value": 89
  },
  {
    "time": "14:25",
    "value": 99
  },
  {
    "time": "14:30",
    "value": 89
  },
  {
    "time": "14:35",
    "value": 99
  },
  {
    "time": "14:40",
    "value": 7689
  },
  {
    "time": "14:45",
    "value": 99
  },
  {
    "time": "14:50",
    "value": 89
  },
  {
    "time": "14:55",
    "value": 99
  },
  {
    "time": "15:00",
    "value": 89
  },
  {
    "time": "15:05",
    "value": 99
  },
  {
    "time": "15:10",
    "value": 89
  },
  {
    "time": "15:15",
    "value": 99
  },
  {
    "time": "15:20",
    "value": 89
  },
  {
    "time": "15:25",
    "value": 99
  },
  {
    "time": "15:30",
    "value": 567
  },
  {
    "time": "15:35",
    "value": 99
  },
  {
    "time": "15:40",
    "value": 89
  },
  {
    "time": "15:45",
    "value": 99
  },
  {
    "time": "15:50",
    "value": 89
  },
  {
    "time": "15:55",
    "value": 99
  }
]
```