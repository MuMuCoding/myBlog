### response with 200

```js
//<response=200>
{
  "yesterday": {
    "activeDeviceIdcnt": 32,
    "activeAccountIdcnt": 10384,
    "newAccountIdcnt": 30,
    "recharge": 199875,
    "rechargeAccountIdcnt": 127,
    "rechargeCnt": 2234
  },
  "weekago": {
    "activeDeviceIdcnt": 17,
    "activeAccountIdcnt": 9999,
    "newAccountIdcnt": 13,
    "recharge": 329875,
    "rechargeAccountIdcnt": 427,
    "rechargeCnt": 7234
  }
}

```
