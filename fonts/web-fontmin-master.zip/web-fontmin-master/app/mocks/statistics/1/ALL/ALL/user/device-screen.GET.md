### response with 200

```js
//<response=200>
//"/statistics/:appId/:channelId/:serverId/user/device-screen", {
//  start: '2015-11-08',
//  to: '2015-11-09'
//}

[
  {
    "deviceScreen": "800*6001",
    "newAccountIdcnt": 40,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1024*7682",
    "newAccountIdcnt": 30,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1920*10803",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1920*10804",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1920*10805",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1920*10806",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1920*10807",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1920*10808",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1920*10809",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1920*108010",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
  {
    "deviceScreen": "1920*108011",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  }
]

```