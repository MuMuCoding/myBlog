### response with 200

```js
//<response=200>
[
  {
    "channelId": "mi",
    "channelName": "mi",
    "newDeviceIdcnt": 2057,
    "newAccountIdcnt": 2057,
    "deviceTransformRate": 0.97,
    "activeAccountIdcnt": 1234,
    "newAccountRetainedIdcnt": 124,
    "newAccountRetainedIdcnt3": 541,
    "newAccountRetainedIdcnt7": 123,
    "newAccountRetainedRate": 0.12,
    "newAccountRetainedRate3": 0.11,
    "newAccountRetainedRate7": 0.09,
    "recharge": 2834,
    "rechargeAccountIdcnt": 203,
    "pur": 0.12,
    "arpu": 2.12,
    "arppu": 3.21,
    "oneDayNewAccountIdcnt": 12384,
    "oneDayNewAccountIdcntRatio": 0.45,
    "firstWeekRatio": 0.23
  },
  {
    "channelId": "07073",
    "channelName": "07073",
    "newDeviceIdcnt": 2057,
    "newAccountIdcnt": 2057,
    "deviceTransformRate": 0.97,
    "activeAccountIdcnt": 1234,
    "newAccountRetainedIdcnt": 124,
    "newAccountRetainedIdcnt3": 541,
    "newAccountRetainedIdcnt7": 123,
    "newAccountRetainedRate": 0.12,
    "newAccountRetainedRate3": 0.11,
    "newAccountRetainedRate7": 0.09,
    "recharge": 2834,
    "rechargeAccountIdcnt": 203,
    "pur": 0.12,
    "arpu": 2.12,
    "arppu": 3.21,
    "oneDayNewAccountIdcnt": 12384,
    "oneDayNewAccountIdcntRatio": 0.45,
    "firstWeekRatio": 0.23
  },
  {
    "channelId": "华为",
    "channelName": "huawei",
    "newDeviceIdcnt": 2057,
    "newAccountIdcnt": 2057,
    "deviceTransformRate": 0.97,
    "activeAccountIdcnt": 1234,
    "newAccountRetainedIdcnt": 124,
    "newAccountRetainedIdcnt3": 541,
    "newAccountRetainedIdcnt7": 123,
    "newAccountRetainedRate": 0.12,
    "newAccountRetainedRate3": 0.11,
    "newAccountRetainedRate7": 0.09,
    "recharge": 2834,
    "rechargeAccountIdcnt": 203,
    "pur": 0.12,
    "arpu": 2.12,
    "arppu": 3.21,
    "oneDayNewAccountIdcnt": 12384,
    "oneDayNewAccountIdcntRatio": 0.45,
    "firstWeekRatio": 0.23
  }
]
```