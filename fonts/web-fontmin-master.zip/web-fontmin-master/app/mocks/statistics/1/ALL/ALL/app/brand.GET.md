
### response with 200

```js
//<response=200>

[{
  "deviceBrand": "mi",
  "deviceCount": 20
},{
  "deviceBrand": "apple",
  "deviceCount": 23
},{
  "deviceBrand": "google",
  "deviceCount": 13
},{
  "deviceBrand": "huawei",
  "deviceCount": 56
},{
  "deviceBrand": "alps",
  "deviceCount": 4
}]

```
