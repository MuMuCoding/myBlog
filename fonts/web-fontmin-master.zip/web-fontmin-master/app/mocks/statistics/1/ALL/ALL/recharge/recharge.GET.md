### response with 200

```js
//<response=200>
{
  "data": [
    {
      "tdate": "2015-11-08",
      "recharge": 18987,
      "rechargeAccountIdcnt": 789,
      "rechargeOrderIdcnt": 1012,
      "arpu": "3.45",
      "arppu": "2.30"
    },
    {
      "tdate": "2015-11-09",
      "recharge": 25215,
      "rechargeAccountIdcnt": 458,
      "rechargeOrderIdcnt": 11234,
      "arpu": "3.45",
      "arppu": "4.30"
    },
    {
      "tdate": "2015-11-10",
      "recharge": 85647,
      "rechargeAccountIdcnt": 659,
      "rechargeOrderIdcnt": 1854,
      "arpu": "1.45",
      "arppu": "2.30"
    },
    {
      "tdate": "2015-11-11",
      "recharge": 85647,
      "rechargeAccountIdcnt": 659,
      "rechargeOrderIdcnt": 1854,
      "arpu": "4.45",
      "arppu": "8.30"
    },
    {
      "tdate": "2015-11-12",
      "recharge": 85647,
      "rechargeAccountIdcnt": 659,
      "rechargeOrderIdcnt": 1854,
      "arpu": "9.45",
      "arppu": "2.30"
    },
    {
      "tdate": "2015-11-13",
      "recharge": 85647,
      "rechargeAccountIdcnt": 659,
      "rechargeOrderIdcnt": 1854,
      "arpu": "8.45",
      "arppu": "6.30"
    },
    {
      "tdate": "2015-11-14",
      "recharge": 85647,
      "rechargeAccountIdcnt": 659,
      "rechargeOrderIdcnt": 1854,
      "arpu": "8.45",
      "arppu": "3.30"
    },
    {
      "tdate": "2015-11-15",
      "recharge": 85647,
      "rechargeAccountIdcnt": 659,
      "rechargeOrderIdcnt": 1854,
      "arpu": "1.45",
      "arppu": "9.30"
    },
    {
      "tdate": "2015-11-16",
      "recharge": 85647,
      "rechargeAccountIdcnt": 659,
      "rechargeOrderIdcnt": 1854,
      "arpu": "2.45",
      "arppu": "12.30"
    },
    {
      "tdate": "2015-11-17",
      "recharge": 85647,
      "rechargeAccountIdcnt": 659,
      "rechargeOrderIdcnt": 1854,
      "arpu": "6.45",
      "arppu": "9.30"
    },
    {
      "tdate": "2015-11-18",
      "recharge": 85647,
      "rechargeAccountIdcnt": 659,
      "rechargeOrderIdcnt": 1854,
      "arpu": "2.45",
      "arppu": "8.30"
    }
  ],
  "avg": {
    "recharge": 45647,
    "rechargeAccountIdcnt": 659,
    "rechargeOrderIdcnt": 1854,
    "arpu": "3.45",
    "arppu": "2.30"
  },
  "sum": {
    "recharge": 956458,
    "rechargeAccountIdcnt": 4524,
    "rechargeOrderIdcnt": 7354,
    "arpu": "3.45",
    "arppu": "2.30"
  }
}
```