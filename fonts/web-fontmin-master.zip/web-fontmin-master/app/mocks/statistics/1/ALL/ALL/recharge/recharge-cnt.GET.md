### response with 200

```js
//<response=200>
[
  {
    "rechargeCnt": 1,
    "accountIdCnt": 12,
    "accountIdCntPercentage": 0.12
  }, {
  "rechargeCnt": 2,
  "accountIdCnt": 12,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 3,
  "accountIdCnt": 34,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 4,
  "accountIdCnt": 24,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 5,
  "accountIdCnt": 15,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 6,
  "accountIdCnt": 24,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 7,
  "accountIdCnt": 16,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 8,
  "accountIdCnt": 34,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 9,
  "accountIdCnt": 24,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 10,
  "accountIdCnt": 26,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 11,
  "accountIdCnt": 11,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 12,
  "accountIdCnt": 8,
  "accountIdCntPercentage": 0.12
}, {
  "rechargeCnt": 13,
  "accountIdCnt": 16,
  "accountIdCntPercentage": 0.12
}
]
```