### response with 200

```js
//<response=200>
[
  {
    "keyRange": "1次",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "2-3次",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "4-5次",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "6-10次",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "11-20次",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "21-50次",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": ">50次",
    "value": 32,
    "percentage": 0.23
  }
]
```