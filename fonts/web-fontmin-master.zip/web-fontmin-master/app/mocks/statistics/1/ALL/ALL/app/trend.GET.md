### response with 200

```js
//<response=200>
[{"tdate":"2016-01-15", "deviceCount":"81", "deviceTotal":"86"},{"tdate":"2016-01-16", "deviceCount":"87", "deviceTotal":"93"},{"tdate":"2016-01-20", "deviceCount":"80", "deviceTotal":"86"},{"tdate":"2016-01-21", "deviceCount":"84", "deviceTotal":"94"},{"tdate":"2016-01-22", "deviceCount":"109", "deviceTotal":"125"},{"tdate":"2016-01-23", "deviceCount":"91", "deviceTotal":"100"},{"tdate":"2016-01-25", "deviceCount":"98", "deviceTotal":"111"}]
```
