### response with 200

```js
//<response=200>
//"/statistics/:appId/:channelId/:serverId/user/new-user", {
//  start: '2015-11-08',
//  to: '2015-11-09'
//}

{
  "data": [
    {
      "tdate": "2015-11-01",
      "newAccountIdcnt": 9,
      "newDeviceIdcnt": 82
    },

    {
      "tdate": "2015-11-02",
      "newAccountIdcnt": 39,
      "newDeviceIdcnt": 38
    },

    {
      "tdate": "2015-11-03",
      "newAccountIdcnt": 99,
      "newDeviceIdcnt": 82
    },

    {
      "tdate": "2015-11-04",
      "newAccountIdcnt": 69,
      "newDeviceIdcnt": 44
    },

    {
      "tdate": "2015-11-05",
      "newAccountIdcnt": 39,
      "newDeviceIdcnt": 66
    },

    {
      "tdate": "2015-11-06",
      "newAccountIdcnt": 99,
      "newDeviceIdcnt": 82
    },

    {
      "tdate": "2015-11-07",
      "newAccountIdcnt": 79,
      "newDeviceIdcnt": 82
    }
  ],
  "avg": {
    "newAccountIdcnt": 99,
    "newDeviceIdcnt": 82
  },
  "sum": {
    "newAccountIdcnt": 99,
    "newDeviceIdcnt": 82
  }
}

```
