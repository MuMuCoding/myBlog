### response with 200

```js
//<response=200>
[{"tdate":"2015-12-07 - 2015-12-13","newDeviceIdcnt":6231,"activeDeviceIdcnt":12700,"newAccountIdcnt":5432,"activeAccountIdcnt":11973,"accountLoginCnt":203437,"avgAccountLoginCnt":16.9913,"avgAccountDur":197.2381,"newAccountRetainedRate":null,"recharge":102313,"rechargeAccountIdcnt":882,"pur":0.0737,"newArpu":0.5810,"arpu":8.5453,"newArppu":22.5429,"arppu":116.0011,"acu":369.1597,"pcu":691},{"tdate":"2015-12-14 - 2015-12-20","newDeviceIdcnt":327563,"activeDeviceIdcnt":334259,"newAccountIdcnt":293922,"activeAccountIdcnt":300792,"accountLoginCnt":693822,"avgAccountLoginCnt":2.3067,"avgAccountDur":21.2483,"newAccountRetainedRate":null,"recharge":113716,"rechargeAccountIdcnt":1947,"pur":0.0065,"newArpu":0.0806,"arpu":0.3781,"newArppu":28.6184,"arppu":58.4058,"acu":325.9410,"pcu":676}]
```
