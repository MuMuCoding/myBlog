### response with 200

```js
//<response=200>
[
  {
    "tdate": "2015-11-01",
    "rechargeVc": 1094,
    "rechargeVcAccountIdcnt": 234
  },
  {
    "tdate": "2015-11-02",
    "rechargeVc": 4534,
    "rechargeVcAccountIdcnt": 124
  },
  {
    "tdate": "2015-11-03",
    "rechargeVc": 4527,
    "rechargeVcAccountIdcnt": 347
  },
  {
    "tdate": "2015-11-04",
    "rechargeVc": 424,
    "rechargeVcAccountIdcnt": 825
  },
  {
    "tdate": "2015-11-05",
    "rechargeVc": 7872,
    "rechargeVcAccountIdcnt": 434
  },
  {
    "tdate": "2015-11-06",
    "rechargeVc": 1274,
    "rechargeVcAccountIdcnt": 354
  },
  {
    "tdate": "2015-11-07",
    "rechargeVc": 5354,
    "rechargeVcAccountIdcnt": 123
  },
  {
    "tdate": "2015-11-08",
    "rechargeVc": 1423,
    "rechargeVcAccountIdcnt": 453
  }
]
```