### response with 200

```js
//<response=200>
//"/statistics/:appId/:channelId/:serverId/user/active-user-area", {
//  start: '2015-11-08',
//  to: '2015-11-09'
//}

[{
  "channelId": "mi1xxx",
  "activeAccountIdcnt": 9,
  "percentage": 0.823
}, {
  "channelId": "百度2",
  "activeAccountIdcnt": 58,
  "percentage": 0.757
}, {
  "channelId": "百度3",
  "activeAccountIdcnt": 88,
  "percentage": 0.757
}, {
  "channelId": "mi4",
  "activeAccountIdcnt": 89,
  "percentage": 0.823
}, {
  "channelId": "百度5",
  "activeAccountIdcnt": 88,
  "percentage": 0.757
}, {
  "channelId": "百度6",
  "activeAccountIdcnt": 88,
  "percentage": 0.757
}, {
  "channelId": "mi7",
  "activeAccountIdcnt": 99,
  "percentage": 0.823
}, {
  "channelId": "百度8",
  "activeAccountIdcnt": 88,
  "percentage": 0.757
}, {
  "channelId": "百度9",
  "activeAccountIdcnt": 88,
  "percentage": 0.757
},
{
  "channelId": "百度10",
  "activeAccountIdcnt": 88,
  "percentage": 0.757
},
{
  "channelId": "百度12",
  "activeAccountIdcnt": 88,
  "percentage": 0.757
},
{
  "channelId": "百度13",
  "activeAccountIdcnt": 68,
  "percentage": 0.757
},
{
  "channelId": "百度14",
  "activeAccountIdcnt": 48,
  "percentage": 0.457
}
]

```