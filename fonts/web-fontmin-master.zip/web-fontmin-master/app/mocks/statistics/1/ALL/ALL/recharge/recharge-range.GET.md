### response with 200

```js
//<response=200>
[
  {
    "keyRange": "10元以下",
    "account": 12,
    "accountPercentage": 0.12,
    "recharge": 145,
    "rechargePercentage": 0.22
  }, {
  "keyRange": "11-50元",
  "account": 15,
  "accountPercentage": 0.12,
  "recharge": 382,
  "rechargePercentage": 0.22
}, {
  "keyRange": "51-100元",
  "account": 17,
  "accountPercentage": 0.12,
  "recharge": 124,
  "rechargePercentage": 0.22
}, {
  "keyRange": "101-200元",
  "account": 18,
  "accountPercentage": 0.12,
  "recharge": 675,
  "rechargePercentage": 0.22
}, {
  "keyRange": "201-500元",
  "account": 45,
  "accountPercentage": 0.12,
  "recharge": 423,
  "rechargePercentage": 0.22
}, {
  "keyRange": "501-1000元",
  "account": 24,
  "accountPercentage": 0.12,
  "recharge": 167,
  "rechargePercentage": 0.22
}, {
  "keyRange": "1000元以上",
  "account": 156,
  "accountPercentage": 0.12,
  "recharge": 623,
  "rechargePercentage": 0.22
}
]
```