### response with 200

```js
//<response=200>
[{"level": "0", "accountIdcnt": 644276}, {"level": "1", "accountIdcnt": 537056}, {
  "level": "10",
  "accountIdcnt": 140419
}, {"level": "100", "accountIdcnt": 15402}, {"level": "101", "accountIdcnt": 15464}, {
  "level": "102",
  "accountIdcnt": 15140
}, {"level": "103", "accountIdcnt": 14900}, {"level": "104", "accountIdcnt": 14670}, {
  "level": "105",
  "accountIdcnt": 14508
}, {"level": "106", "accountIdcnt": 14596}, {"level": "107", "accountIdcnt": 14532}, {
  "level": "108",
  "accountIdcnt": 14448
}, {"level": "109", "accountIdcnt": 13208}, {"level": "11", "accountIdcnt": 122915}, {
  "level": "110",
  "accountIdcnt": 13472
}, {"level": "111", "accountIdcnt": 13412}, {"level": "112", "accountIdcnt": 13588}, {
  "level": "113",
  "accountIdcnt": 13180
}, {"level": "114", "accountIdcnt": 13600}, {"level": "115", "accountIdcnt": 13656}, {
  "level": "116",
  "accountIdcnt": 13704
}, {"level": "117", "accountIdcnt": 13912}, {"level": "118", "accountIdcnt": 13464}, {
  "level": "119",
  "accountIdcnt": 13168
}, {"level": "12", "accountIdcnt": 125803}, {"level": "120", "accountIdcnt": 13780}, {
  "level": "121",
  "accountIdcnt": 13756
}, {"level": "122", "accountIdcnt": 14020}, {"level": "123", "accountIdcnt": 13556}, {
  "level": "124",
  "accountIdcnt": 13218
}, {"level": "125", "accountIdcnt": 13232}, {"level": "126", "accountIdcnt": 13000}, {
  "level": "127",
  "accountIdcnt": 12756
}, {"level": "128", "accountIdcnt": 12604}, {"level": "129", "accountIdcnt": 12408}, {
  "level": "13",
  "accountIdcnt": 124575
}, {"level": "130", "accountIdcnt": 11824}, {"level": "131", "accountIdcnt": 11580}, {
  "level": "132",
  "accountIdcnt": 11384
}, {"level": "133", "accountIdcnt": 10812}, {"level": "134", "accountIdcnt": 10516}, {
  "level": "135",
  "accountIdcnt": 10108
}, {"level": "136", "accountIdcnt": 9680}, {"level": "137", "accountIdcnt": 9612}, {
  "level": "138",
  "accountIdcnt": 9240
}, {"level": "139", "accountIdcnt": 8860}, {"level": "14", "accountIdcnt": 123886}, {
  "level": "140",
  "accountIdcnt": 8280
}, {"level": "141", "accountIdcnt": 8064}, {"level": "142", "accountIdcnt": 7516}, {
  "level": "143",
  "accountIdcnt": 7292
}, {"level": "144", "accountIdcnt": 6872}, {"level": "145", "accountIdcnt": 6360}, {
  "level": "146",
  "accountIdcnt": 5712
}, {"level": "147", "accountIdcnt": 4992}, {"level": "148", "accountIdcnt": 4664}, {
  "level": "149",
  "accountIdcnt": 4072
}, {"level": "15", "accountIdcnt": 112049}, {"level": "150", "accountIdcnt": 13834}, {
  "level": "16",
  "accountIdcnt": 106810
}, {"level": "17", "accountIdcnt": 97268}, {"level": "18", "accountIdcnt": 94065}, {
  "level": "19",
  "accountIdcnt": 87726
}, {"level": "2", "accountIdcnt": 250045}, {"level": "20", "accountIdcnt": 100572}, {
  "level": "200",
  "accountIdcnt": 4
}, {"level": "21", "accountIdcnt": 105485}, {"level": "22", "accountIdcnt": 132965}, {
  "level": "227",
  "accountIdcnt": 8
}, {"level": "228", "accountIdcnt": 4}, {"level": "229", "accountIdcnt": 4}, {
  "level": "23",
  "accountIdcnt": 103327
}, {"level": "24", "accountIdcnt": 99691}, {"level": "25", "accountIdcnt": 123986}, {
  "level": "26",
  "accountIdcnt": 109435
}, {"level": "27", "accountIdcnt": 107384}, {"level": "28", "accountIdcnt": 93923}, {
  "level": "29",
  "accountIdcnt": 99803
}, {"level": "3", "accountIdcnt": 243090}, {"level": "30", "accountIdcnt": 129256}, {
  "level": "31",
  "accountIdcnt": 132448
}, {"level": "32", "accountIdcnt": 127332}, {"level": "33", "accountIdcnt": 124443}, {
  "level": "331",
  "accountIdcnt": 8
}, {"level": "34", "accountIdcnt": 118228}, {"level": "35", "accountIdcnt": 120140}, {
  "level": "36",
  "accountIdcnt": 116966
}, {"level": "361", "accountIdcnt": 4}, {"level": "362", "accountIdcnt": 8}, {
  "level": "363",
  "accountIdcnt": 8
}, {"level": "37", "accountIdcnt": 108475}, {"level": "373", "accountIdcnt": 4}, {
  "level": "374",
  "accountIdcnt": 4
}, {"level": "375", "accountIdcnt": 4}, {"level": "376", "accountIdcnt": 4}, {
  "level": "38",
  "accountIdcnt": 110410
}, {"level": "39", "accountIdcnt": 104098}, {"level": "4", "accountIdcnt": 202706}, {
  "level": "40",
  "accountIdcnt": 115011
}, {"level": "40001", "accountIdcnt": 92}, {"level": "40002", "accountIdcnt": 40}, {
  "level": "40003",
  "accountIdcnt": 32
}, {"level": "40004", "accountIdcnt": 96}, {"level": "40005", "accountIdcnt": 124}, {
  "level": "40006",
  "accountIdcnt": 8
}, {"level": "40008", "accountIdcnt": 16}, {"level": "40009", "accountIdcnt": 4}, {
  "level": "40010",
  "accountIdcnt": 28
}, {"level": "40011", "accountIdcnt": 36}, {"level": "40012", "accountIdcnt": 92}, {
  "level": "40013",
  "accountIdcnt": 64
}, {"level": "40014", "accountIdcnt": 24}, {"level": "40015", "accountIdcnt": 36}, {
  "level": "40016",
  "accountIdcnt": 44
}, {"level": "40017", "accountIdcnt": 4}, {"level": "40018", "accountIdcnt": 304}, {
  "level": "40019",
  "accountIdcnt": 32
}, {"level": "40020", "accountIdcnt": 124}, {"level": "40021", "accountIdcnt": 36}, {
  "level": "40023",
  "accountIdcnt": 8
}, {"level": "40025", "accountIdcnt": 64}, {"level": "40026", "accountIdcnt": 20}, {
  "level": "40027",
  "accountIdcnt": 92
}, {"level": "40028", "accountIdcnt": 96}, {"level": "40029", "accountIdcnt": 48}, {
  "level": "40030",
  "accountIdcnt": 64
}, {"level": "40031", "accountIdcnt": 96}, {"level": "40032", "accountIdcnt": 64}, {
  "level": "40033",
  "accountIdcnt": 120
}, {"level": "40034", "accountIdcnt": 44}, {"level": "40035", "accountIdcnt": 120}, {
  "level": "40036",
  "accountIdcnt": 384
}, {"level": "40037", "accountIdcnt": 460}, {"level": "407", "accountIdcnt": 12}, {
  "level": "41",
  "accountIdcnt": 106617
}, {"level": "41000", "accountIdcnt": 40}, {"level": "42", "accountIdcnt": 101310}, {
  "level": "422",
  "accountIdcnt": 4
}, {"level": "43", "accountIdcnt": 96226}, {"level": "435", "accountIdcnt": 36}, {
  "level": "436",
  "accountIdcnt": 16
}, {"level": "437", "accountIdcnt": 8}, {"level": "438", "accountIdcnt": 8}, {
  "level": "439",
  "accountIdcnt": 8
}, {"level": "44", "accountIdcnt": 92704}, {"level": "440", "accountIdcnt": 8}, {
  "level": "441",
  "accountIdcnt": 8
}, {"level": "442", "accountIdcnt": 8}, {"level": "443", "accountIdcnt": 8}, {
  "level": "444",
  "accountIdcnt": 8
}, {"level": "445", "accountIdcnt": 8}, {"level": "446", "accountIdcnt": 8}, {
  "level": "447",
  "accountIdcnt": 8
}, {"level": "448", "accountIdcnt": 8}, {"level": "449", "accountIdcnt": 8}, {
  "level": "45",
  "accountIdcnt": 96808
}, {"level": "450", "accountIdcnt": 16}, {"level": "46", "accountIdcnt": 94611}, {
  "level": "47",
  "accountIdcnt": 93126
}, {"level": "48", "accountIdcnt": 94368}, {"level": "49", "accountIdcnt": 92677}, {
  "level": "5",
  "accountIdcnt": 203135
}, {"level": "50", "accountIdcnt": 100764}, {"level": "51", "accountIdcnt": 68704}, {
  "level": "52",
  "accountIdcnt": 70114
}, {"level": "53", "accountIdcnt": 71867}, {"level": "54", "accountIdcnt": 70770}, {
  "level": "55",
  "accountIdcnt": 71087
}, {"level": "56", "accountIdcnt": 71925}, {"level": "57", "accountIdcnt": 72154}, {
  "level": "58",
  "accountIdcnt": 70616
}, {"level": "59", "accountIdcnt": 63308}, {"level": "6", "accountIdcnt": 188515}, {
  "level": "60",
  "accountIdcnt": 72128
}, {"level": "61", "accountIdcnt": 73886}, {"level": "62", "accountIdcnt": 71034}, {
  "level": "63",
  "accountIdcnt": 70443
}, {"level": "64", "accountIdcnt": 74996}, {"level": "65", "accountIdcnt": 79280}, {
  "level": "66",
  "accountIdcnt": 70198
}, {"level": "67", "accountIdcnt": 50844}, {"level": "68", "accountIdcnt": 37639}, {
  "level": "69",
  "accountIdcnt": 25384
}, {"level": "7", "accountIdcnt": 174659}, {"level": "70", "accountIdcnt": 18384}, {
  "level": "71",
  "accountIdcnt": 11396
}, {"level": "72", "accountIdcnt": 14584}, {"level": "73", "accountIdcnt": 16048}, {
  "level": "74",
  "accountIdcnt": 16072
}, {"level": "75", "accountIdcnt": 11204}, {"level": "76", "accountIdcnt": 15028}, {
  "level": "77",
  "accountIdcnt": 15632
}, {"level": "78", "accountIdcnt": 14836}, {"level": "79", "accountIdcnt": 10600}, {
  "level": "8",
  "accountIdcnt": 151703
}, {"level": "80", "accountIdcnt": 15020}, {"level": "81", "accountIdcnt": 15632}, {
  "level": "82",
  "accountIdcnt": 15460
}, {"level": "83", "accountIdcnt": 11608}, {"level": "84", "accountIdcnt": 14932}, {
  "level": "85",
  "accountIdcnt": 15480
}, {"level": "86", "accountIdcnt": 15276}, {"level": "87", "accountIdcnt": 11124}, {
  "level": "88",
  "accountIdcnt": 14356
}, {"level": "89", "accountIdcnt": 15364}, {"level": "9", "accountIdcnt": 162751}, {
  "level": "90",
  "accountIdcnt": 15472
}, {"level": "91", "accountIdcnt": 10704}, {"level": "92", "accountIdcnt": 14332}, {
  "level": "93",
  "accountIdcnt": 15602
}, {"level": "94", "accountIdcnt": 15268}, {"level": "95", "accountIdcnt": 12656}, {
  "level": "96",
  "accountIdcnt": 14760
}, {"level": "97", "accountIdcnt": 15346}, {"level": "98", "accountIdcnt": 15184}, {
  "level": "99",
  "accountIdcnt": 15082
}]
```