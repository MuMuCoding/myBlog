### response with 200

```js
//<response=200>
[{"tdate":"2015-11","newDeviceIdcnt":65367,"activeDeviceIdcnt":80251,"newAccountIdcnt":67428,"activeAccountIdcnt":81218,"accountLoginCnt":1351130,"avgAccountLoginCnt":16.6358,"avgAccountDur":182.0308,"newAccountRetainedRate":null,"recharge":843132,"rechargeAccountIdcnt":5421,"pur":0.0667,"newArpu":1.1334,"arpu":10.3811,"newArppu":34.7852,"arppu":155.5307,"acu":884.8333,"pcu":1341}]
```
