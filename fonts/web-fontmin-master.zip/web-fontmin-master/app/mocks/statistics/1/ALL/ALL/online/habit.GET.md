### response with 200

```js
//<response=200>
{
  "data": [{
    "tdate": "2015-11-06",
    "accountLoginCnt": 234,
    "avgAccountDur": 514
  }, {
    "tdate": "2015-11-07",
    "accountLoginCnt": 231,
    "avgAccountDur": 854
  }, {
    "tdate": "2015-11-08",
    "accountLoginCnt": 124,
    "avgAccountDur": 754
  }, {
    "tdate": "2015-11-09",
    "accountLoginCnt": 235,
    "avgAccountDur": 456
  }, {
    "tdate": "2015-11-10",
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }, {
    "tdate": "2015-11-11",
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }, {
    "tdate": "2015-11-12",
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }, {
    "tdate": "2015-11-13",
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }, {
    "tdate": "2015-11-14",
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }, {
    "tdate": "2015-11-15",
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }, {
    "tdate": "2015-11-16",
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }, {
    "tdate": "2015-11-17",
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }, {
    "tdate": "2015-11-18",
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }],
  "avg": {
    "accountLoginCnt": 141,
    "avgAccountDur": 231
  }
}


```