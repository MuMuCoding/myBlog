### response with 200

```js
//<response=200>
//"/statistics/:appId/:channelId/:serverId/user/device-model", {
//  start: '2015-11-08',
//  to: '2015-11-09'
//}

[
  {
    "deviceModel": "coolpad 830",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
  },
 {
    "deviceModel": "samsum pad",
    "newAccountIdcnt": 50,
    "activeAccountIdcnt": 40,
    "newDeviceIdcnt": 30,
    "activeDeviceIdcnt": 80
 },
 {
    "deviceModel": "小米42",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
 },
 {
    "deviceModel": "小米43",
    "newAccountIdcnt": 90,
    "activeAccountIdcnt": 70,
    "newDeviceIdcnt": 53,
    "activeDeviceIdcnt": 54
 },
 {
    "deviceModel": "小米44",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
 },
 {
    "deviceModel": "小米45",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
 },
 {
    "deviceModel": "小米46",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
 },
 {
    "deviceModel": "小米47",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
 },
 {
    "deviceModel": "小米48",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
 },
 {
    "deviceModel": "小米49",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
 },
 {
    "deviceModel": "小米543",
    "newAccountIdcnt": 10,
    "activeAccountIdcnt": 30,
    "newDeviceIdcnt": 23,
    "activeDeviceIdcnt": 54
 }

]

```