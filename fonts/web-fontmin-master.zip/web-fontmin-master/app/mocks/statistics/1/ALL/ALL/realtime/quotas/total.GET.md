### response with 200

```js
//<response=200>
{
  "total": {
    "totalAccountIdcnt": 8984,
    "totalRecharge": 9994564
  }
}

```
