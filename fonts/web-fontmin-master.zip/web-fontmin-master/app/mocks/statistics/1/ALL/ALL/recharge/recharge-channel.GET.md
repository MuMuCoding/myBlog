### response with 200

```js
//<response=200>
[
  {
    "channelId": "mi",
    "recharge": 15,
    "percentage": 0.12
  },
  {
    "channelId": "mi1",
    "recharge": 35,
    "percentage": 0.12
  },
  {
    "channelId": "mi2",
    "recharge": 42,
    "percentage": 0.12
  },
  {
    "channelId": "mi3",
    "recharge": 15,
    "percentage": 0.12
  },
  {
    "channelId": "mi4",
    "recharge": 37,
    "percentage": 0.12
  },
  {
    "channelId": "mi5",
    "recharge": 12,
    "percentage": 0.12
  },
  {
    "channelId": "mi6",
    "recharge": 24,
    "percentage": 0.12
  },
  {
    "channelId": "mi7",
    "recharge": 31,
    "percentage": 0.12
  },
  {
    "channelId": "mi8",
    "recharge": 12,
    "percentage": 0.12
  },
  {
    "channelId": "mi9",
    "recharge": 24,
    "percentage": 0.12
  },
  {
    "channelId": "mi10",
    "recharge": 11,
    "percentage": 0.12
  },
  {
    "channelId": "mi11",
    "recharge": 19,
    "percentage": 0.12
  }
]
```