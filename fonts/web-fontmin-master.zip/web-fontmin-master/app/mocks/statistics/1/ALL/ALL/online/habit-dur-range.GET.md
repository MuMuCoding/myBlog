### response with 200

```js
//<response=200>
[
  {
    "keyRange": "<10s",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "11-60s",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "1-3mins",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "3-10mins",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "10-30mins",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "30-60mins",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "1-2hours",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "2-4hours",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": ">4hours",
    "value": 32,
    "percentage": 0.23
  },
  {
    "keyRange": "未知",
    "value": 32,
    "percentage": 0.23
  }
]
```