### response with 200

```js
//<response=200>
// 返回200
[{
  "deviceId": 1,
  "deviceDesc": "first device",
  "deviceToken": "13579",
  "createTime": "2015-12-01"
},{
  "deviceId": 2,
  "deviceDesc": "second device",
  "deviceToken": "24680",
  "createTime": "2015-12-12"
}]
```
