### response with 200

```js
//<response=200>
// 返回200
{"msgId":"xg_msg_706501f422924a37ab2ff2f2af3bacc5","msgName":"z","msgCustomParams":null,"msgTitle":"z","msgType":"notification","msgContent":"z","afterAction":"app","extraParams":"{\"a\":\"b\",\"c\":\"d\"}","notifyWithSound":true,"notifyWithLamps":true,"notifyWithShock":true,"receiverGroup":"all","filter":null,"deviceTokens":null,"alias":null,"aliasType":null,"aliasDimension":null,"sendTimeType":"immediate","sendTime":null,"expireTime":1456455157000,"sendFrequency":0,"msgIconSmall":null,"msgIconLarge":null,"msgSound":null,"msgStyleNumber":0,"test":false,"thirdFilter":null,"actionUrl":null,"actionActivity":null,"actionCustom":null,"apsSoundType":"default","apsCustomSound":null,"apsBadge":0,"apsCategoryID":null}
```
