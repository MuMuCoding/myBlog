### response with 200

```js
//<response=200>
// 返回200
{
  "cursor": 0,
  "count": 2,
  "total": 2,
  "data": [{
    "id": 1,
    "type": "h消息",
    "desc": "first msg",
    "to": "山山",
    "createTime": "2015-12-01",
    "receivedCount": 123,
    "openedCount": 40,
    "ignoredCount": 83,
    "status": "已发送"
  },{
    "id": 2,
    "type": "通知",
    "desc": "second msg",
    "to": "道川",
    "createTime": "2015-12-12",
    "receivedCount": 5,
    "openedCount": 4,
    "ignoredCount": 1,
    "status": "已发送"
  }]
}
```
