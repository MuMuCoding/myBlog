### response with 200

```js
//<response=200>
// 返回200
{
    "uAppKey": "123456",
    "uMessageKey": "umeng-message-key",
    "uMasterKey": "umeng-master-key",
    "masterPackageName": "123456",
    "slavePackageName": ["haha", "hehe"],
    "hasDevCertification": true,
    "devCertificationPwd": "123456",
    "hasPrdCertification": false,
    "prdCertificationPwd": "654321"
}
```
