### response with 200

```js
//<response=200>
// 返回200
{
    "xg": true,
    "umeng": true
}
```
