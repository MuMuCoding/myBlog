### response with 200

```js
//<response=200>
// 返回200
{
    "oauthConsumerKey": "48vTuxFmthO6Obw77E1i45uiev0klKm0KWC1NijQ",
    "oauthConsumerSecret": "xZlrEfmaZ96q303JeU5peGvwDbHOp3pTqDBvwqUX",
    "oauthToken": "RLsdJD0fJ8koxYMmLO6QCO4tR5aaSuaao8ASVsGD",
    "oauthTokenSecret": "e3lMXzxS93pgfFBIN1w5v27BMZBA8YsaJMJ5645c"
}
```
