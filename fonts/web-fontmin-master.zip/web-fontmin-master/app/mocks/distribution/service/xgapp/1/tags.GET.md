# 查询我的应用
## request

```js
//<request>
```

## response with 200

```js
//<response=200>
{
  "message": "ok",
  "ret": 0,
  "tag": "tag",
  "data": [
    {
      "xgappid": "1",
      "name": "Tag1"
    },
    {
      "xgappid": "1",
      "name": "Tag2"
    }
  ]
}
```
