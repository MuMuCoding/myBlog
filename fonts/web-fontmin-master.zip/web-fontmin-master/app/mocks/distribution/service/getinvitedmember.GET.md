# config

## request

```js
//<request>
{
  appid: '55dda90ee13823574d000060'
}
```

## response with 200

```js
//<response=200>
{
"message": "ok",
  "ret": 0,
  "data": [
    {
      "appid": "55b1a886e13823361e00000a",
      "usertype": 0,
      "email": "258627934@qq.com",
      "addtime": 1437706374,
      "id": "55b1a886e13823361e00000c"
    },
    {
      "appid": "55b1a886e13823361e00000a",
      "usertype": -1,
      "email": "258627934@qq.com",
      "addtime": 1437706374,
      "id": "55b1a886e13823361e00000d"
    },
    {
      "appid": "55b1a886e13823361e00000a",
      "usertype": 1,
      "email": "258627934@qq.com",
      "addtime": 1437706409,
      "id": "55b1a8a9e13823361e00000f"
    }
  ]

}
```
