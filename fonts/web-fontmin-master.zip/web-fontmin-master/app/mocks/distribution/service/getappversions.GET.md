# 查询我的应用
## request

```js
//<request>
```

## response with 200

```js
//<response=200>

{
  "message": "ok",
  "ret": 0,
  "data": {
    "allrows": 1,
    "appversions": [
      {
        "id": "568c86c3683f196fa03e6fb0",
        "appid": "568c86c3683f196fa03e6faf",
        "createtime": 1452050115,
        "status": 0,
        "package": {
          "filename": "",
          "url": "",
          "lanurl": "",
          "platform": 2,
          "size": 4442001,
          "logo": "",
          "appname": "TakoDev",
          "bundleid": "com.ksg.tako.zhh",
          "package": "com.ksg.tako.zhh",
          "version": "0.5.11",
          "buildnumber": 607
        },
        "releasenote": "哈哈哈哈和哈哈哈哈哈哈哈哈哈你们这些愚蠢的人类",
        "forceupgrade": false,
        "userid": "568a422f683f196fa03e6f8d",
        "downloadcount": 1,
        "firstcreator": "568a422f683f196fa03e6f8d",
        "firstcreated": "2016-01-06T11:15:15.865+08:00",
        "lastmodifier": "568a422f683f196fa03e6f8d",
        "lastmodified": "2016-01-06T11:15:15.865+08:00"
      },
      {
        "id": "568c86c3683f196fa03e6fb0",
        "appid": "568c86c3683f196fa03e6faf",
        "createtime": 1452050115,
        "status": 0,
        "package": {
          "filename": "",
          "url": "",
          "lanurl": "",
          "platform": 2,
          "size": 4442001,
          "logo": "",
          "appname": "TakoDev",
          "bundleid": "com.ksg.tako.zhh",
          "package": "com.ksg.tako.zhh",
          "version": "0.5.11",
          "buildnumber": 607
        },
        "releasenote": "",
        "forceupgrade": false,
        "userid": "568a422f683f196fa03e6f8d",
        "downloadcount": 1,
        "firstcreator": "568a422f683f196fa03e6f8d",
        "firstcreated": "2016-01-06T11:15:15.865+08:00",
        "lastmodifier": "568a422f683f196fa03e6f8d",
        "lastmodified": "2016-01-06T11:15:15.865+08:00"
      }
    ],
    "nextcursor": 1
  }
}
```
