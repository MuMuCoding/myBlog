# 创建游戏


### request

```js
//<request>
{
  "appid": "55b1a886e13823361e00000a",
  "users": [
    {
      "usertype": 1,
      "tangjie2@kingsoft.com",
    }
  ]
}

```

### response with 200

```js
//<response=200>
// 200
{
 "message": "ok",
  "ret": 0
}
```
