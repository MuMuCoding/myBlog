# 查询我的应用
## request

```js
//<request>
```

## response with 200

```js
//<response=200>

{
    "message": "ok",
    "ret": 0,
    "data": {
        "app": {
            "id": "569cb68f7b25d5c027a72a86",
            "createtime": 1453110927,
            "platform": 2,
            "logourl": "http://tako.kssws.ks-cdn.com/logo/fc4d76c2-b505-4c23-6c00-407e82396f13.png",
            "uri": "axfx",
            "appname": "觅品儿",
            "pinyin": "mipiner",
            "packagename": "com.forsigner.mipinr",
            "status": 0,
            "disabled": false,
            "priority": 0,
            "releaseversion": {
                "id": "569cb6b57b25d5c027a72aad",
                "appid": "569cb68f7b25d5c027a72a86",
                "createtime": 1453110965,
                "status": 0,
                "package": {
                    "filename": "",
                    "url": "*",
                    "lanurl": "",
                    "platform": 2,
                    "size": 28902466,
                    "logo": "http://tako.kssws.ks-cdn.com/logo/fc4d76c2-b505-4c23-6c00-407e82396f13.png",
                    "appname": "觅品儿",
                    "bundleid": "com.forsigner.mipinr",
                    "package": "com.forsigner.mipinr",
                    "version": "1.0.0",
                    "buildnumber": 10000
                },
                "releasenote": "",
                "forceupgrade": false,
                "userid": "xg__7b3cc1098e1d35872d8d8fb91002f3f9f78e800c4cbb00e40b419d31fa60c444",
                "downloadcount": 1,
                "firstcreator": "xg__7b3cc1098e1d35872d8d8fb91002f3f9f78e800c4cbb00e40b419d31fa60c444",
                "firstcreated": "2016-01-18T17:56:05.318+08:00",
                "lastmodifier": "xg__7b3cc1098e1d35872d8d8fb91002f3f9f78e800c4cbb00e40b419d31fa60c444",
                "lastmodified": "2016-01-18T17:56:05.318+08:00"
            },
            "userid": "xg__7b3cc1098e1d35872d8d8fb91002f3f9f78e800c4cbb00e40b419d31fa60c444",
            "isshare": false,
            "ispublic": false,
            "sharefeedback": true,
            "password": "",
            "downloadcount": 1,
            "appdesc": "",
            "imgurls": [ ],
            "lastreleased": 1453110965318613500,
            "domain": "",
            "lanhost": "",
            "mailmsg": { },
            "firstcreator": "xg__7b3cc1098e1d35872d8d8fb91002f3f9f78e800c4cbb00e40b419d31fa60c444",
            "firstcreated": "2016-01-18T17:55:27.302+08:00",
            "lastmodifier": "xg__7b3cc1098e1d35872d8d8fb91002f3f9f78e800c4cbb00e40b419d31fa60c444",
            "lastmodified": "2016-01-18T17:56:05.318+08:00"
        }
    }
}
```
