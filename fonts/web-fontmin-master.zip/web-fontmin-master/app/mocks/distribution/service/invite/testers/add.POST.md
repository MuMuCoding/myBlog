# 邀请测试人员


### request

```js
//<request>
{
  appid: '56936d2f7b25d56e62bbbf4b',
  members: [{
    email: 'forsigner@qq.com'
  }]
}

```

### response with 200

```js
//<response=200>
// 200
{message: 'ok', ret: 0}
```
