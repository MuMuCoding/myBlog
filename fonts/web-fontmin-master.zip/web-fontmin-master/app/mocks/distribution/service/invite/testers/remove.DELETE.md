# config

### request

```js
//<request>
{ "ids": ["", ""] }
```

### response with 200

```js
//<response=200>
{"message":"ok","ret":0}
```
