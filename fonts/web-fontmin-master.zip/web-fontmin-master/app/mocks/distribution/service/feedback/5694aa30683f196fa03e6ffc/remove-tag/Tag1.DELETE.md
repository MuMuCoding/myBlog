# 创建游戏


### request

```js
//<request>
{
}

```

### response with 200

```js
//<response=200>
// 200
{"message":"ok","ret":0}
```
