# config

### request

```js
//<request>
{
  id: "5694aa30683f196fa03e6ffc",
  status: "open"
}
```

### response with 200

```js
//<response=200>
{"message":"ok","ret":0}
```
