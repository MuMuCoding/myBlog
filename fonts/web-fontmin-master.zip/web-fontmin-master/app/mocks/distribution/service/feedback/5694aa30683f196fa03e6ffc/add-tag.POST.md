
# 保存设置


### request

```js
//<request>
{
  tag: "1234"
}

```

### response with 200

```js
//<response=200>
// 200
{"message":"ok","ret":0}
```
