# config
## request

```js
//<request>
```

## response with 200

```js
//<response=200>

{
  message: "ok",
  ret: 0,
  data: {
    KSSAccessKeyId: "cNz/9EdJaDMh0FAhDzZA",
    policy: "eyJleHBpcmF0aW9uIjogIjIwMTYtMDEtMDdUMDk6MDg6MDMuMDAwWiIsImNvbmRpdGlvbnMiOiBbeyJhY2wiOiAicHJpdmF0ZSIgfSx7ImJ1Y2tldCI6ICJ0YWtvIiB9LFsic3RhcnRzLXdpdGgiLCAiJGtleSIsICJ0ZXN0L2FwcC8iXSxbInN0YXJ0cy13aXRoIiwgIiRuYW1lIiwgIiJdXX0=",
    signature: "NCfW0Rjq+WxFpLULKvgXduwvzrU=",
    bucket_name: "tako",
    key: "test/app/ddbff269-9634-4b11-6bf1-af208d9df21c",
    uploadDomain: "http://kssws.ks-cdn.com/tako"
  }
}
```
