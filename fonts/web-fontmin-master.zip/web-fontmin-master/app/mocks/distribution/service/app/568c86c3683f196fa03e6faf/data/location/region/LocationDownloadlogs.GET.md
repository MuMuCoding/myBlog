### response with 200

```js
//<response=200>
// 200
{
  message: "ok",
  ret: 0,
  tag: "package",
  data: {
    data: [{
      locationid: "新疆维吾尔族自治区",
      count: 999
    }, {
      locationid: "广西",
      count: 83
    }, {
      locationid: "湖南1",
      count: 94
    }, {
      locationid: "湖南2",
      count: 94
    }, {
      locationid: "湖南3",
      count: 94
    }, {
      locationid: "湖南4",
      count: 94
    }, {
      locationid: "湖南5",
      count: 94
    }, {
      locationid: "湖南6",
      count: 94
    }, {
      locationid: "湖南7",
      count: 94
    }, {
      locationid: "湖南8",
      count: 94
    }, {
      locationid: "湖南9",
      count: 94
    }, {
      locationid: "湖南0",
      count: 94
    }]
  }
}
```
