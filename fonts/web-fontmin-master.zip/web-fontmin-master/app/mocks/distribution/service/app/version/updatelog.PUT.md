# 编辑更新日志


### request

```js
//<request>
{
  id: 'exffwrwfwf',
  log: '这个更新日志'
}

```

### response with 200

```js
//<response=200>
// 200
{"message":"ok","ret":0}
```
