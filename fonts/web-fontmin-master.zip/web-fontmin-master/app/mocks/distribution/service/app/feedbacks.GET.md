# 查询我的应用
## request

```js
//<request>
```

## response with 200

```js
//<response=200>
{
    "message": "ok",
    "ret": 0,
    "data": {
        "allrows": 1,
        "feedbacks": [
            {
                "id": "5694aa30683f196fa03e6ffc",
                "note": "wqdqwdqweq",
                "createtime": 1452583472,
                "appid": "568c86c3683f196fa03e6faf",
                "versionid": "568c86c3683f196fa03e6fb0",
                "taskid": "",
                "client": {
                    "client_name": "Chrome",
                    "client_version": "44.0.2403.125",
                    "os_name": "Windows 8.1",
                    "platform": "Windows"
                },
                "voiceurl": "",
                "imgurls": [
                    "http://tako.kssws.ks-cdn.com/test/screenshot/8a057405-47e4-42b5-6773-2e1e526f4c73.jpg"
                ],
                "userid": "xg__85bcaca7da4126779d7d4ac205422e777763bf07f645ae13948e77762545ff12",
                "username": "1476063504",
                "nickname": "1476063504",
                "userimage": "",
                "status": "close",
                "liked": false,
                "likers": [ ],
                "comments":[
                    {
                        "id":"568a422f683f196fa03e6f8d",
                        "userid":"xg__85bcaca7da4126779d7d4ac205422e777763bf07f645ae13948e77762545ff12",
                        "username":"",
                        "nickname":"",
                        "targetid":"",
                        "rolename":"角色名称",
                        "targetname":"",
                        "targetnick":"",
                        "comment":"测试",
                        "time":"2015-12-25T11:28:50.346+08:00"
                    }],
                "tags": [
                    {
                        "id": "568c86c3683f196fa03e6faf",
                        "xgappid": "90000027",
                        "name": "Tag2",
                        "createtime": "2016-02-17T13:42:47.636+08:00"
                    },
                    {
                        "id": "568c86c3683f196fa03e6faf",
                        "xgappid": "90000027",
                        "name": "Tag1",
                        "createtime": "2016-02-18T15:39:14.28+08:00"
                    }
                ],
                "firstcreated": "2016-01-12T15:24:32.13+08:00",
                "lastmodified": "2016-01-12T15:24:32.13+08:00"
            },

            {
                "id": "5694aa30683f196fa03e6ffd",
                "note": "wqdqwdqweq",
                "createtime": 1452583472,
                "appid": "568c86c3683f196fa03e6faf",
                "versionid": "568c86c3683f196fa03e6fb0",
                "taskid": "",
                "client": {
                    "client_name": "Chrome",
                    "client_version": "44.0.2403.125",
                    "os_name": "Windows 8.1",
                    "platform": "Windows"
                },
                "voiceurl": "",
                "imgurls": [
                    "http://tako.kssws.ks-cdn.com/test/screenshot/8a057405-47e4-42b5-6773-2e1e526f4c73.jpg"
                ],
                "userid": "568a422f683f196fa03e6f8d",
                "username": "1476063504",
                "nickname": "1476063504",
                "userimage": "",
                "status": "close",
                "liked": false,
                "likers": [ ],
                "comments": [ ],
                "firstcreated": "2016-01-12T15:24:32.13+08:00",
                "lastmodified": "2016-01-12T15:24:32.13+08:00"
            }
        ],
        "nextcursor": 1
    }
}
```
