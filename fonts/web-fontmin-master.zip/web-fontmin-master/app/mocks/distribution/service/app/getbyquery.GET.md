# 查询应用的历史信息
## request

```js
//<request>
```

## response with 200

```js
//<response=200>
{
    "message": "ok",
    "ret": 0,
    "tag": "app",
    "data": {
        "id": "56025f22e138234835000084",
        "xgappid": "98000028",
        "createtime": 1442996002,
        "platform": 2,
        "logourl": "tako/test/logo/357269fc-945a-48bf-581c-581b8b377ff9.png",
        "uri": "tako",
        "url": "",
        "appname": "TakoQA",
        "pinyin": "",
        "packagename": "com.ksg.tako.qa",
        "status": 0,
        "disabled": false,
        "priority": 0,
        "releaseversion": {
            "id": "57188956e13823e1dd5981ff",
            "appid": "56025f22e138234835000084",
            "createtime": 1461225814,
            "status": 0,
            "package": {
                "filename": "",
                "url": "tako/test/app/a6f769c0-cf58-483f-51aa-4fa1d0a19793.apk",
                "lanurl": "",
                "md5": "",
                "platform": 2,
                "size": 4633407,
                "logo": "tako/test/logo/357269fc-945a-48bf-581c-581b8b377ff9.png",
                "appname": "TakoQA",
                "bundleid": "com.ksg.tako.qa",
                "package": "com.ksg.tako.qa",
                "version": "0.6",
                "buildnumber": 902
            },
            "releasenote": "add apk delete",
            "forceupgrade": false,
            "userid": "tako_55b6f570e138237ac6000001",
            "downloadcount": 0,
            "viewcount": 0,
            "url": "",
            "patchstatus": 0,
            "releasetime": "2016-04-21T16:03:34.055+08:00",
            "firstcreator": "tako_55b6f570e138237ac6000001",
            "firstcreated": "2016-04-21T16:03:34.055+08:00",
            "lastmodifier": "tako_55b6f570e138237ac6000001",
            "lastmodified": "2016-04-21T16:03:34.055+08:00"
        },
        "userid": "tako_55b6f570e138237ac6000001",
        "isshare": false,
        "ispublic": true,
        "sharefeedback": true,
        "password": "",
        "downloadcount": 214,
        "viewcount": 660,
        "appdesc": "TakoQAAndroid",
        "imgurls": [ ],
        "domain": "",
        "lanhost": "",
        "channelid": "",
        "channelname": "",
        "mailmsg": { },
        "releasepolicy": 0,
        "firstcreator": "tako_55b6f570e138237ac6000001",
        "firstcreated": "2015-09-23T16:13:22.739+08:00",
        "lastmodifier": "tako_55b6f570e138237ac6000001",
        "lastmodified": "2016-04-21T16:03:34.056+08:00"
    }
}
```
