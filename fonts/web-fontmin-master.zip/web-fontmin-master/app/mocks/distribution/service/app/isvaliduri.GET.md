# 创建游戏


### request

```js
//<request>
{
  appid:566149ada2aa4c20389901e6,
  appuri:2lk1
}

```

### response with 200

```js
//<response=200>
// 200
{"message":"ok","ret":0}
```
