# 创建游戏


### request

```js
//<request>
{
  "appid": "55b1a886e13823361e00000a",
  "memberids": [
    "55b087a9e1382326cf00000c"
  ]
}

```

### response with 200

```js
//<response=200>
// 200
{"message":"ok","ret":0}
```
