### response with 200

```js
//<response=200>
// 200
{
  message: "ok",
  ret: 0,
  tag: "package",
  data: [{
    date: "2015-11-12",
    count: 12
  }, {
    date: "2015-11-18",
    count: 24
  }, {
    date: "2015-11-22",
    count: 9
  }]
}
```
