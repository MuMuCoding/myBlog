### response with 200

```js
//<response=200>
// 200
{
  message: "ok",
  ret: 0,
  tag: "package",
  data: [{
    region: "广东",
    count: 14
  }, {
    region: "广西",
    count: 83
  }, {
    region: "湖南",
    count: 94
  }]
}
```
