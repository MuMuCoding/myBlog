# config

### request

```js
//<request>

```

### response with 200

```js
//<response=200>

{
  message: "ok",
  ret: 0,
  tag: "upload",
  data: {
    fileserver: "ks3-private"
  }
}
```
