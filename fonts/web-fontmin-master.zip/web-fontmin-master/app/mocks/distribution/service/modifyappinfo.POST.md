
# 保存设置


### request

```js
//<request>
{
  appdesc: "",
  appid: "566149ada2aa4c20389901e6",
  appname: "HockeyApp",
  ispublic: false,
  isshare: false,
  password: "",
  releasenote: "for test",
  sharefeedback: true,
  uri: "2lk1"
}

```

### response with 200

```js
//<response=200>
// 200
{"message":"ok","ret":0}
```
