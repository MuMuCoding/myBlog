## response with 200

```js
//<response=200>

{"message":"ok","ret":0,"tag":"user","data":{"uid":"xg__85bcaca7da4126779d7d4ac205422e777763bf07f645ae13948e77762545ff12"}}
```
